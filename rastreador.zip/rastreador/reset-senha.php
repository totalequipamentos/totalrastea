<?php
/**
 * Script para resetar a senha do WordPress
 * Acesse via navegador: http://locminas.com.br/reset-senha.php
 */

// Configurações do banco de dados
define( 'DB_NAME', 'locminas' );
define( 'DB_USER', 'locminas' );
define( 'DB_PASSWORD', 'Hrastrea2025' );
define( 'DB_HOST', 'mysql.locminas.com.br' );

// Conectar ao banco de dados
$conn = new mysqli( DB_HOST, DB_USER, DB_PASSWORD, DB_NAME );

if ( $conn->connect_error ) {
    die( 'Erro de conexão: ' . $conn->connect_error );
}

// Configurar charset
$conn->set_charset( 'utf8' );

// Email do usuário que quer resetar
$user_email = 'financeiro@locminas.com.br';
$nova_senha = 'Senha123!'; // ALTERE ESTA SENHA TEMPORÁRIA

// Gerar hash da senha (WordPress usa phpass)
require_once( dirname( __FILE__ ) . '/wp-load.php' );

$user = get_user_by( 'email', $user_email );

if ( $user ) {
    $user_id = $user->ID;
    
    // Usar função do WordPress para gerar hash seguro
    $hashed_password = wp_hash_password( $nova_senha );
    
    // Atualizar no banco de dados
    $sql = "UPDATE wp_users SET user_pass = '" . $conn->real_escape_string( $hashed_password ) . "' WHERE ID = " . intval( $user_id );
    
    if ( $conn->query( $sql ) === TRUE ) {
        echo '<div style="padding: 20px; background: #d4edda; border: 1px solid #28a745; color: #155724; border-radius: 4px;">';
        echo '<h2>✓ Senha redefinida com sucesso!</h2>';
        echo '<p><strong>Email:</strong> ' . htmlspecialchars( $user_email ) . '</p>';
        echo '<p><strong>Nova Senha Temporária:</strong> ' . htmlspecialchars( $nova_senha ) . '</p>';
        echo '<p><a href="http://locminas.com.br/wp-login.php" style="color: #155724; font-weight: bold;">Clique aqui para fazer login</a></p>';
        echo '<p style="margin-top: 20px; font-size: 12px; color: #666;"><strong>IMPORTANTE:</strong> Altere a senha no painel de administração após fazer login!</p>';
        echo '</div>';
    } else {
        echo '<div style="padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; border-radius: 4px;">';
        echo '<h2>✗ Erro ao redefinir a senha</h2>';
        echo '<p>Erro: ' . $conn->error . '</p>';
        echo '</div>';
    }
} else {
    echo '<div style="padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; border-radius: 4px;">';
    echo '<h2>✗ Usuário não encontrado</h2>';
    echo '<p>Email: ' . htmlspecialchars( $user_email ) . '</p>';
    echo '</div>';
}

$conn->close();
?>
