<div style="min-height:400px;height:100%;padding:10px;box-sizing:border-box;">
<iframe id="buy_frame" name="buy_frame" src="<?php echo esc_url( $iframe_url ); ?>" style="height:100%;width:100%" scrolling="auto">
</iframe>
</div>
