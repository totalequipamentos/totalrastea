/**
 * Vehicle Tracker Public Scripts
 */
;(($) => {
  const VTPublic = {
    map: null,
    markers: {},
    selectedVehicle: null,
    updateInterval: null,

    /**
     * Initialize public tracking
     */
    init: function () {
      if ($("#vt-public-map").length) {
        this.initMap("vt-public-map")
        this.bindEvents()
        this.loadVehicles()
        this.startAutoUpdate()
      }

      // Initialize single maps
      $(".vt-single-map").each((_, el) => {
        this.initSingleMap($(el))
      })

      // Load addresses for fleet cards
      this.loadFleetAddresses()
    },

    /**
     * Initialize main tracking map
     */
    initMap: function (containerId) {
      var mapOptions = {
        center: window.vtPublic.mapCenter,
        zoom: window.vtPublic.mapZoom,
        mapTypeId: window.google.maps.MapTypeId.ROADMAP,
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
        styles: [
          {
            featureType: "poi",
            elementType: "labels",
            stylers: [{ visibility: "off" }],
          },
        ],
      }

      this.map = new window.google.maps.Map(document.getElementById(containerId), mapOptions)
    },

    /**
     * Initialize single vehicle map
     */
    initSingleMap: function ($el) {
      var vehicleId = $el.data("vehicle-id")

      $.ajax({
        url: window.vtPublic.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_vehicle_position",
          vehicle_id: vehicleId,
          nonce: window.vtPublic.nonce,
        },
        success: (response) => {
          if (response.success && response.data) {
            var vehicle = response.data
            var position = { lat: vehicle.latitude, lng: vehicle.longitude }

            var map = new window.google.maps.Map($el[0], {
              center: position,
              zoom: 15,
              mapTypeId: window.google.maps.MapTypeId.ROADMAP,
              mapTypeControl: false,
              streetViewControl: false,
              fullscreenControl: true,
            })

            new window.google.maps.Marker({
              position: position,
              map: map,
              icon: this.getMarkerIcon(vehicle),
              title: vehicle.plate,
            })
          }
        },
      })
    },

    /**
     * Bind UI events
     */
    bindEvents: function () {
      var self = this

      // Vehicle card click
      $(document).on("click", ".vt-vehicle-card", function () {
        var vehicleId = $(this).data("vehicle-id")
        self.selectVehicle(vehicleId)
      })

      // Filter buttons
      $(document).on("click", ".vt-filter", function () {
        $(".vt-filter").removeClass("active")
        $(this).addClass("active")
        self.filterVehicles($(this).data("filter"))
      })

      // Search input
      $(document).on("input", ".vt-search", function () {
        self.searchVehicles($(this).val())
      })

      // Fit all button
      $(document).on("click", ".vt-fit-all", () => {
        self.fitAllVehicles()
      })

      // Show trail button
      $(document).on("click", ".vt-show-trail", () => {
        if (self.selectedVehicle) {
          self.showVehicleTrail(self.selectedVehicle)
        }
      })

      // Panel close
      $(document).on("click", ".vt-panel-close", () => {
        self.closePanel()
      })
    },

    /**
     * Load all vehicles
     */
    loadVehicles: function () {
      $.ajax({
        url: window.vtPublic.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_user_vehicles_positions",
          nonce: window.vtPublic.nonce,
        },
        success: (response) => {
          if (response.success && response.data) {
            this.updateVehiclesList(response.data)
            response.data.forEach((vehicle) => {
              this.updateMarker(vehicle)
            })
          }
        },
      })
    },

    /**
     * Update vehicles list
     */
    updateVehiclesList: (vehicles) => {
      vehicles.forEach((vehicle) => {
        var $card = $('.vt-vehicle-card[data-vehicle-id="' + vehicle.id + '"]')
        if ($card.length) {
          var statusClass = vehicle.ignition ? (vehicle.speed > 0 ? "moving" : "online") : "offline"
          $card.find(".vt-status-dot").removeClass("online moving offline").addClass(statusClass)
          $card.find(".vt-vehicle-speed").text(vehicle.speed + " km/h")
        }
      })
    },

    /**
     * Update vehicle marker on map
     */
    updateMarker: function (vehicle) {
      var position = new window.google.maps.LatLng(vehicle.latitude, vehicle.longitude)

      if (this.markers[vehicle.id]) {
        this.markers[vehicle.id].setPosition(position)
        this.markers[vehicle.id].setIcon(this.getMarkerIcon(vehicle))
      } else {
        var marker = new window.google.maps.Marker({
          position: position,
          map: this.map,
          icon: this.getMarkerIcon(vehicle),
          title: vehicle.plate,
        })

        marker.addListener("click", () => {
          this.selectVehicle(vehicle.id)
        })

        this.markers[vehicle.id] = marker
      }
    },

    /**
     * Get marker icon
     */
    getMarkerIcon: (vehicle) => {
      var color
      var rotation = vehicle.direction || 0

      if (!vehicle.ignition) {
        color = "#9ca3af"
      } else if (vehicle.speed > 0) {
        color = "#3b82f6"
      } else {
        color = "#22c55e"
      }

      var svg =
        '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">' +
        '<circle cx="16" cy="16" r="14" fill="' +
        color +
        '" stroke="white" stroke-width="2"/>' +
        '<path d="M16 8 L22 22 L16 18 L10 22 Z" fill="white" transform="rotate(' +
        rotation +
        ', 16, 16)"/>' +
        "</svg>"

      return {
        url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg),
        scaledSize: new window.google.maps.Size(32, 32),
        anchor: new window.google.maps.Point(16, 16),
      }
    },

    /**
     * Select vehicle
     */
    selectVehicle: function (vehicleId) {
      this.selectedVehicle = vehicleId

      $(".vt-vehicle-card").removeClass("active")
      $('.vt-vehicle-card[data-vehicle-id="' + vehicleId + '"]').addClass("active")

      if (this.markers[vehicleId]) {
        this.map.panTo(this.markers[vehicleId].getPosition())
        this.map.setZoom(15)
      }

      this.showVehiclePanel(vehicleId)
    },

    /**
     * Show vehicle panel
     */
    showVehiclePanel: (vehicleId) => {
      $.ajax({
        url: window.vtPublic.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_vehicle_details",
          vehicle_id: vehicleId,
          nonce: window.vtPublic.nonce,
        },
        success: (response) => {
          if (response.success) {
            var v = response.data
            var html =
              '<div class="vt-panel-content">' +
              '<button class="vt-panel-close"><span class="dashicons dashicons-no-alt"></span></button>' +
              "<h4>" +
              v.plate +
              " - " +
              v.model +
              "</h4>" +
              "<p><strong>Velocidade:</strong> " +
              v.speed +
              " km/h</p>" +
              "<p><strong>Status:</strong> " +
              (v.ignition ? "Online" : "Offline") +
              "</p>" +
              "<p><strong>Última atualização:</strong> " +
              v.last_update +
              "</p>" +
              "</div>"

            $(".vt-vehicle-panel").html(html).show()
          }
        },
      })
    },

    /**
     * Close panel
     */
    closePanel: function () {
      this.selectedVehicle = null
      $(".vt-vehicle-panel").hide()
      $(".vt-vehicle-card").removeClass("active")
    },

    /**
     * Filter vehicles
     */
    filterVehicles: function (filter) {
      var self = this

      $(".vt-vehicle-card").each(function () {
        var $card = $(this)
        var vehicleId = $card.data("vehicle-id")
        var marker = self.markers[vehicleId]
        var $dot = $card.find(".vt-status-dot")
        var show = true

        if (filter === "online") {
          show = $dot.hasClass("online") || $dot.hasClass("moving")
        } else if (filter === "moving") {
          show = $dot.hasClass("moving")
        }

        $card.toggle(show)
        if (marker) marker.setVisible(show)
      })
    },

    /**
     * Search vehicles
     */
    searchVehicles: function (query) {
      var self = this
      query = query.toLowerCase()

      $(".vt-vehicle-card").each(function () {
        var $card = $(this)
        var vehicleId = $card.data("vehicle-id")
        var marker = self.markers[vehicleId]
        var text = $card.text().toLowerCase()
        var show = text.indexOf(query) !== -1

        $card.toggle(show)
        if (marker) marker.setVisible(show)
      })
    },

    /**
     * Fit all vehicles
     */
    fitAllVehicles: function () {
      var bounds = new window.google.maps.LatLngBounds()
      var hasMarkers = false

      Object.keys(this.markers).forEach((id) => {
        bounds.extend(this.markers[id].getPosition())
        hasMarkers = true
      })

      if (hasMarkers) {
        this.map.fitBounds(bounds)
      }
    },

    /**
     * Show vehicle trail
     */
    showVehicleTrail: function (vehicleId) {
      $.ajax({
        url: window.vtPublic.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_vehicle_history",
          vehicle_id: vehicleId,
          hours: 24,
          nonce: window.vtPublic.nonce,
        },
        success: (response) => {
          if (response.success && response.data.length > 0) {
            var path = response.data.map((point) => new window.google.maps.LatLng(point.latitude, point.longitude))

            new window.google.maps.Polyline({
              path: path,
              geodesic: true,
              strokeColor: "#3b82f6",
              strokeOpacity: 0.8,
              strokeWeight: 3,
              map: this.map,
            })
          }
        },
      })
    },

    /**
     * Load addresses for fleet cards
     */
    loadFleetAddresses: () => {
      $(".vt-address").each(function () {
        var $el = $(this)
        var lat = $el.data("lat")
        var lng = $el.data("lng")

        if (lat && lng) {
          var geocoder = new window.google.maps.Geocoder()
          geocoder.geocode({ location: { lat: lat, lng: lng } }, (results, status) => {
            if (status === "OK" && results[0]) {
              $el.text(results[0].formatted_address)
            } else {
              $el.text(lat.toFixed(4) + ", " + lng.toFixed(4))
            }
          })
        }
      })
    },

    /**
     * Start auto update
     */
    startAutoUpdate: function () {
      this.updateInterval = setInterval(() => {
        this.loadVehicles()
      }, window.vtPublic.updateInterval)
    },

    /**
     * Stop auto update
     */
    stopAutoUpdate: function () {
      if (this.updateInterval) {
        clearInterval(this.updateInterval)
      }
    },
  }

  // Initialize on document ready
  $(document).ready(() => {
    if (typeof window.google !== "undefined" && window.google.maps) {
      window.VTPublic = VTPublic
      VTPublic.init()
    }
  })
})(window.jQuery)
