/**
 * Vehicle Tracker Admin Scripts
 */
;(($) => {
  // Global namespace
  window.VehicleTracker = window.VehicleTracker || {}
  const VehicleTracker = window.VehicleTracker

  // Declare vtAdmin variable before using it
  const vtAdmin = window.vtAdmin || {}

  /**
   * Dashboard Module
   */
  VehicleTracker.Dashboard = {
    init: function () {
      this.bindEvents()
      this.startAutoRefresh()
    },

    bindEvents: function () {
      $(document).on("click", ".vt-refresh-stats", this.refreshStats.bind(this))
    },

    startAutoRefresh: function () {
      // Refresh stats every 30 seconds
      setInterval(this.refreshStats.bind(this), 30000)
    },

    refreshStats: () => {
      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_dashboard_stats",
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            VehicleTracker.Dashboard.updateStats(response.data)
          }
        },
      })
    },

    updateStats: (data) => {
      if (data.total_vehicles !== undefined) {
        $("#vt-stat-total").text(data.total_vehicles)
      }
      if (data.online_vehicles !== undefined) {
        $("#vt-stat-online").text(data.online_vehicles)
      }
      if (data.moving_vehicles !== undefined) {
        $("#vt-stat-moving").text(data.moving_vehicles)
      }
      if (data.alerts_today !== undefined) {
        $("#vt-stat-alerts").text(data.alerts_today)
      }
    },
  }

  /**
   * Vehicles Module
   */
  VehicleTracker.Vehicles = {
    init: function () {
      this.bindEvents()
    },

    bindEvents: function () {
      $(document).on("click", ".vt-delete-vehicle", this.confirmDelete.bind(this))
      $(document).on("click", ".vt-block-vehicle", this.toggleBlock.bind(this))
      $(document).on("submit", "#vt-vehicle-form", this.saveVehicle.bind(this))
    },

    confirmDelete: (e) => {
      if (!confirm(vtAdmin.i18n.confirmDelete)) {
        e.preventDefault()
      }
    },

    toggleBlock: (e) => {
      e.preventDefault()
      var $btn = $(e.currentTarget)
      var vehicleId = $btn.data("vehicle-id")
      var action = $btn.data("action")

      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_toggle_vehicle_block",
          vehicle_id: vehicleId,
          block_action: action,
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            location.reload()
          } else {
            alert(response.data.message || vtAdmin.i18n.error)
          }
        },
      })
    },

    saveVehicle: (e) => {
      var $form = $(e.currentTarget)
      var $submitBtn = $form.find('button[type="submit"]')

      $submitBtn.prop("disabled", true).text(vtAdmin.i18n.saving)
    },
  }

  /**
   * Geofences Module
   */
  VehicleTracker.Geofences = {
    map: null,
    drawingManager: null,
    currentShape: null,
    geofences: [],

    init: function () {
      if ($("#vt-geofence-map").length) {
        this.initMap()
        this.bindEvents()
      }
    },

    initMap: function () {
      var mapOptions = {
        center: { lat: -23.5505, lng: -46.6333 }, // São Paulo
        zoom: 12,
        mapTypeId: "roadmap",
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
      }

      this.map = new window.google.maps.Map(document.getElementById("vt-geofence-map"), mapOptions)

      // Initialize drawing manager
      this.drawingManager = new window.google.maps.drawing.DrawingManager({
        drawingMode: null,
        drawingControl: false,
        circleOptions: {
          fillColor: "#0073aa",
          fillOpacity: 0.3,
          strokeColor: "#0073aa",
          strokeWeight: 2,
          clickable: true,
          editable: true,
        },
        polygonOptions: {
          fillColor: "#0073aa",
          fillOpacity: 0.3,
          strokeColor: "#0073aa",
          strokeWeight: 2,
          clickable: true,
          editable: true,
        },
        rectangleOptions: {
          fillColor: "#0073aa",
          fillOpacity: 0.3,
          strokeColor: "#0073aa",
          strokeWeight: 2,
          clickable: true,
          editable: true,
        },
      })

      this.drawingManager.setMap(this.map)

      // Drawing complete listener
      window.google.maps.event.addListener(this.drawingManager, "overlaycomplete", this.onDrawingComplete.bind(this))

      // Load existing geofences
      this.loadGeofences()
    },

    bindEvents: function () {
      $(document).on("click", ".vt-draw-circle", () => this.startDrawing("circle"))
      $(document).on("click", ".vt-draw-polygon", () => this.startDrawing("polygon"))
      $(document).on("click", ".vt-draw-rectangle", () => this.startDrawing("rectangle"))
      $(document).on("click", ".vt-clear-shape", this.clearCurrentShape.bind(this))
      $(document).on("submit", "#vt-geofence-form", this.saveGeofence.bind(this))
      $(document).on("click", ".vt-delete-geofence", this.deleteGeofence.bind(this))
    },

    startDrawing: function (type) {
      this.clearCurrentShape()

      var mode
      switch (type) {
        case "circle":
          mode = window.google.maps.drawing.OverlayType.CIRCLE
          break
        case "polygon":
          mode = window.google.maps.drawing.OverlayType.POLYGON
          break
        case "rectangle":
          mode = window.google.maps.drawing.OverlayType.RECTANGLE
          break
      }

      this.drawingManager.setDrawingMode(mode)
      $("#vt-geofence-type").val(type)
    },

    onDrawingComplete: function (event) {
      this.clearCurrentShape()
      this.currentShape = event.overlay
      this.drawingManager.setDrawingMode(null)

      // Update coordinates field
      this.updateCoordinates()
      
      if (event.type === "circle") {
        window.google.maps.event.addListener(this.currentShape, "radius_changed", () => {
          this.updateCoordinates()
        })
        window.google.maps.event.addListener(this.currentShape, "center_changed", () => {
          this.updateCoordinates()
        })
      } else {
        window.google.maps.event.addListener(this.currentShape.getPath(), "set_at", () => {
          this.updateCoordinates()
        })
        window.google.maps.event.addListener(this.currentShape.getPath(), "insert_at", () => {
          this.updateCoordinates()
        })
      }
    },

    updateCoordinates: function () {
      if (!this.currentShape) return

      var coordinates = {}
      var type = $("#vt-geofence-type").val()

      if (type === "circle") {
        coordinates = {
          center: {
            lat: this.currentShape.getCenter().lat(),
            lng: this.currentShape.getCenter().lng(),
          },
          radius: this.currentShape.getRadius(),
        }
      } else if (type === "rectangle") {
        var bounds = this.currentShape.getBounds()
        coordinates = {
          north: bounds.getNorthEast().lat(),
          south: bounds.getSouthWest().lat(),
          east: bounds.getNorthEast().lng(),
          west: bounds.getSouthWest().lng(),
        }
      } else {
        var path = this.currentShape.getPath()
        coordinates = []
        path.forEach((point) => {
          coordinates.push({
            lat: point.lat(),
            lng: point.lng(),
          })
        })
      }

      $("#vt-geofence-coordinates").val(JSON.stringify(coordinates))
    },

    clearCurrentShape: function () {
      if (this.currentShape) {
        this.currentShape.setMap(null)
        this.currentShape = null
      }
      $("#vt-geofence-coordinates").val("")
    },

    loadGeofences: function () {
      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_geofences",
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success && response.data) {
            response.data.forEach((geofence) => {
              this.drawGeofence(geofence)
            })
          }
        },
      })
    },

    drawGeofence: function (geofence) {
      var shape
      var coordinates = JSON.parse(geofence.coordinates)
      var color = geofence.color || "#0073aa"

      if (geofence.type === "circle") {
        shape = new window.google.maps.Circle({
          center: coordinates.center,
          radius: coordinates.radius,
          fillColor: color,
          fillOpacity: 0.2,
          strokeColor: color,
          strokeWeight: 2,
          map: this.map,
        })
      } else if (geofence.type === "rectangle") {
        shape = new window.google.maps.Rectangle({
          bounds: {
            north: coordinates.north,
            south: coordinates.south,
            east: coordinates.east,
            west: coordinates.west,
          },
          fillColor: color,
          fillOpacity: 0.2,
          strokeColor: color,
          strokeWeight: 2,
          map: this.map,
        })
      } else {
        shape = new window.google.maps.Polygon({
          paths: coordinates,
          fillColor: color,
          fillOpacity: 0.2,
          strokeColor: color,
          strokeWeight: 2,
          map: this.map,
        })
      }

      // Add info window
      var infoWindow = new window.google.maps.InfoWindow({
        content: "<strong>" + geofence.name + "</strong>",
      })
      
      shape.addListener("click", () => {
        infoWindow.setPosition(shape.getBounds ? shape.getBounds().getCenter() : shape.getCenter())
        infoWindow.open(this.map)
      })

      this.geofences.push({
        id: geofence.id,
        shape: shape,
      })
    },

    saveGeofence: (e) => {
      e.preventDefault()

      var $form = $(e.currentTarget)
      var formData = $form.serialize()

      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: formData + "&action=vt_save_geofence&nonce=" + vtAdmin.nonce,
        success: (response) => {
          if (response.success) {
            location.reload()
          } else {
            alert(response.data.message || vtAdmin.i18n.error)
          }
        },
      })
    },

    deleteGeofence: (e) => {
      if (!confirm(vtAdmin.i18n.confirmDelete)) {
        e.preventDefault()
      }
    },
  }

  /**
   * Alerts Module
   */
  VehicleTracker.Alerts = {
    init: function () {
      this.bindEvents()
      this.checkNewAlerts()
    },

    bindEvents: function () {
      $(document).on("click", ".vt-mark-read", this.markAsRead.bind(this))
      $(document).on("click", ".vt-mark-all-read", this.markAllAsRead.bind(this))
    },

    checkNewAlerts: function () {
      setInterval(() => {
        $.ajax({
          url: vtAdmin.ajaxUrl,
          type: "POST",
          data: {
            action: "vt_check_new_alerts",
            nonce: vtAdmin.nonce,
          },
          success: (response) => {
            if (response.success && response.data.count > 0) {
              this.showAlertNotification(response.data.count)
            }
          },
        })
      }, 60000) // Check every minute
    },

    showAlertNotification: (count) => {
      // Update admin bar badge
      var $badge = $("#wp-admin-bar-vt-alerts .vt-alert-count")
      if ($badge.length) {
        $badge.text(count)
      }

      // Show browser notification if permitted
      if (Notification.permission === "granted") {
        new Notification("Vehicle Tracker", {
          body: count + " novo(s) alerta(s)",
          icon: vtAdmin.pluginUrl + "/assets/images/icon.png",
        })
      }
    },

    markAsRead: (e) => {
      e.preventDefault()
      var alertId = $(e.currentTarget).data("alert-id")

      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_mark_alert_read",
          alert_id: alertId,
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            $(e.currentTarget).closest(".vt-alert-item").fadeOut()
          }
        },
      })
    },

    markAllAsRead: (e) => {
      e.preventDefault()

      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_mark_all_alerts_read",
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            location.reload()
          }
        },
      })
    },
  }

  /**
   * Settings Module
   */
  VehicleTracker.Settings = {
    init: function () {
      this.bindEvents()
    },

    bindEvents: function () {
      $(document).on("click", ".vt-test-connection", this.testConnection.bind(this))
      $(document).on("click", ".vt-sync-avatek", this.syncAvatek.bind(this))
    },

    testConnection: (e) => {
      e.preventDefault()
      var $btn = $(e.currentTarget)
      var type = $btn.data("type")

      $btn.prop("disabled", true).text(vtAdmin.i18n.testing)

      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_test_connection",
          type: type,
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            alert(vtAdmin.i18n.connectionSuccess)
          } else {
            alert(response.data.message || vtAdmin.i18n.connectionError)
          }
        },
        complete: () => {
          $btn.prop("disabled", false).text(vtAdmin.i18n.testConnection)
        },
      })
    },

    syncAvatek: (e) => {
      e.preventDefault()
      var $btn = $(e.currentTarget)

      $btn.prop("disabled", true).text(vtAdmin.i18n.syncing)

      $.ajax({
        url: vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_sync_avatek",
          nonce: vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            alert(vtAdmin.i18n.syncSuccess.replace("%d", response.data.count))
            location.reload()
          } else {
            alert(response.data.message || vtAdmin.i18n.syncError)
          }
        },
        complete: () => {
          $btn.prop("disabled", false).text(vtAdmin.i18n.syncAvatek)
        },
      })
    },
  }

  /**
   * Initialize on document ready
   */
  $(document).ready(() => {
    // Initialize modules based on current page
    VehicleTracker.Dashboard.init()
    VehicleTracker.Vehicles.init()
    VehicleTracker.Alerts.init()
    VehicleTracker.Settings.init()

    // Initialize geofences if on geofence page
    if ($("#vt-geofence-map").length) {
      // Wait for Google Maps to load
      if (typeof window.google !== "undefined" && window.google.maps) {
        VehicleTracker.Geofences.init()
      }
    }

    // Request notification permission
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission()
    }
  })
})(window.jQuery)
