/**
 * Vehicle Tracker - Real-time Tracking Map
 */
;(($) => {
  window.VTTrackingMap = {
    map: null,
    markers: {},
    infoWindows: {},
    polylines: {},
    selectedVehicle: null,
    updateInterval: null,
    bounds: null,

    /**
     * Initialize the tracking map
     */
    init: function (containerId, options) {
      var defaultOptions = {
        center: { lat: -23.5505, lng: -46.6333 },
        zoom: 12,
        mapTypeId: window.google.maps.MapTypeId.ROADMAP,
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
        styles: [
          {
            featureType: "poi",
            elementType: "labels",
            stylers: [{ visibility: "off" }],
          },
        ],
      }

      var mapOptions = $.extend({}, defaultOptions, options)
      this.map = new window.google.maps.Map(document.getElementById(containerId), mapOptions)
      this.bounds = new window.google.maps.LatLngBounds()

      this.bindEvents()
      this.loadVehicles()
      this.startAutoUpdate()

      return this
    },

    /**
     * Bind UI events
     */
    bindEvents: function () {
      var self = this

      // Vehicle list item click
      $(document).on("click", ".vt-vehicle-item", function () {
        var vehicleId = $(this).data("vehicle-id")
        self.selectVehicle(vehicleId)
      })

      // Filter buttons
      $(document).on("click", ".vt-filter-btn", function () {
        $(".vt-filter-btn").removeClass("active")
        $(this).addClass("active")
        self.filterVehicles($(this).data("filter"))
      })

      // Search input
      $(document).on("input", ".vt-search-input", function () {
        self.searchVehicles($(this).val())
      })

      // Panel close button
      $(document).on("click", ".vt-panel-close", () => {
        self.closeVehiclePanel()
      })

      // Fit all button
      $(document).on("click", ".vt-fit-all", () => {
        self.fitAllVehicles()
      })

      // Follow vehicle toggle
      $(document).on("click", ".vt-follow-vehicle", function () {
        self.toggleFollow($(this).data("vehicle-id"))
      })

      // Show history button
      $(document).on("click", ".vt-show-history", function () {
        self.showVehicleHistory($(this).data("vehicle-id"))
      })

      // Send command buttons
      $(document).on("click", ".vt-send-command", function () {
        self.sendCommand($(this).data("vehicle-id"), $(this).data("command"))
      })
    },

    /**
     * Load all vehicles from server
     */
    loadVehicles: function () {
      

      $.ajax({
        url: window.vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_vehicles_positions",
          nonce: window.vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success && response.data) {
            this.updateVehiclesList(response.data)
            response.data.forEach((vehicle) => {
              this.updateVehicleMarker(vehicle)
            })

            // Fit bounds on first load
            if (Object.keys(this.markers).length > 0) {
              this.fitAllVehicles()
            }
          }
        },
      })
    },

    /**
     * Update vehicles list in sidebar
     */
    updateVehiclesList: (vehicles) => {
      var $list = $(".vt-vehicle-list")
      var html = ""

      var stats = {
        total: vehicles.length,
        online: 0,
        moving: 0,
        offline: 0,
      }

      vehicles.forEach((vehicle) => {
        var statusClass = vehicle.ignition ? (vehicle.speed > 0 ? "moving" : "online") : "offline"

        if (vehicle.ignition) {
          stats.online++
          if (vehicle.speed > 0) {
            stats.moving++
          }
        } else {
          stats.offline++
        }

        html +=
          '<div class="vt-vehicle-item" data-vehicle-id="' +
          vehicle.id +
          '">' +
          '<span class="vt-vehicle-status ' +
          statusClass +
          '"></span>' +
          '<div class="vt-vehicle-details">' +
          '<span class="vt-vehicle-plate">' +
          vehicle.plate +
          "</span>" +
          '<span class="vt-vehicle-info">' +
          (vehicle.driver_name || vehicle.model) +
          "</span>" +
          '<span class="vt-vehicle-speed">' +
          vehicle.speed +
          " km/h</span>" +
          "</div>" +
          "</div>"
      })

      $list.html(html)

      // Update stats
      $("#vt-total-count").text(stats.total)
      $("#vt-online-count").text(stats.online)
      $("#vt-moving-count").text(stats.moving)
    },

    /**
     * Update or create vehicle marker on map
     */
    updateVehicleMarker: function (vehicle) {
      var position = new window.google.maps.LatLng(vehicle.latitude, vehicle.longitude)

      if (this.markers[vehicle.id]) {
        // Update existing marker
        this.markers[vehicle.id].setPosition(position)
        this.markers[vehicle.id].setIcon(this.getMarkerIcon(vehicle))

        // Animate marker movement
        if (this.selectedVehicle === vehicle.id) {
          this.map.panTo(position)
        }
      } else {
        // Create new marker
        var marker = new window.google.maps.Marker({
          position: position,
          map: this.map,
          icon: this.getMarkerIcon(vehicle),
          title: vehicle.plate,
        })
        
        marker.addListener("click", () => {
          this.selectVehicle(vehicle.id)
        })

        this.markers[vehicle.id] = marker
      }

      // Update bounds
      this.bounds.extend(position)
    },

    /**
     * Get marker icon based on vehicle status
     */
    getMarkerIcon: (vehicle) => {
      var color
      var rotation = vehicle.direction || 0

      if (!vehicle.ignition) {
        color = "#9ca3af" // gray - offline
      } else if (vehicle.speed > 0) {
        color = "#3b82f6" // blue - moving
      } else {
        color = "#22c55e" // green - stopped with ignition on
      }

      // SVG arrow icon
      var svg =
        '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">' +
        '<circle cx="16" cy="16" r="14" fill="' +
        color +
        '" stroke="white" stroke-width="2"/>' +
        '<path d="M16 8 L22 22 L16 18 L10 22 Z" fill="white" transform="rotate(' +
        rotation +
        ', 16, 16)"/>' +
        "</svg>"

      return {
        url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg),
        scaledSize: new window.google.maps.Size(32, 32),
        anchor: new window.google.maps.Point(16, 16),
      }
    },

    /**
     * Select a vehicle and show panel
     */
    selectVehicle: function (vehicleId) {
      
      this.selectedVehicle = vehicleId

      // Highlight in list
      $(".vt-vehicle-item").removeClass("active")
      $('.vt-vehicle-item[data-vehicle-id="' + vehicleId + '"]').addClass("active")

      // Center map on vehicle
      if (this.markers[vehicleId]) {
        this.map.panTo(this.markers[vehicleId].getPosition())
        this.map.setZoom(15)
      }

      // Load vehicle details
      $.ajax({
        url: window.vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_vehicle_details",
          vehicle_id: vehicleId,
          nonce: window.vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            this.showVehiclePanel(response.data)
          }
        },
      })
    },

    /**
     * Show vehicle details panel
     */
    showVehiclePanel: function (vehicle) {
      var html =
        '<div class="vt-vehicle-panel">' +
        '<button class="vt-panel-close"><span class="dashicons dashicons-no-alt"></span></button>' +
        '<div class="vt-panel-header">' +
        "<h3>" +
        vehicle.plate +
        "</h3>" +
        "<span>" +
        vehicle.brand +
        " " +
        vehicle.model +
        " - " +
        vehicle.color +
        "</span>" +
        "</div>" +
        '<div class="vt-panel-body">' +
        '<div class="vt-panel-info-grid">' +
        '<div class="vt-panel-info-item">' +
        '<span class="vt-info-label">Velocidade</span>' +
        '<span class="vt-info-value">' +
        vehicle.speed +
        " km/h</span>" +
        "</div>" +
        '<div class="vt-panel-info-item">' +
        '<span class="vt-info-label">Direção</span>' +
        '<span class="vt-info-value">' +
        this.getDirectionName(vehicle.direction) +
        "</span>" +
        "</div>" +
        '<div class="vt-panel-info-item">' +
        '<span class="vt-info-label">Ignição</span>' +
        '<span class="vt-info-value">' +
        (vehicle.ignition ? "Ligada" : "Desligada") +
        "</span>" +
        "</div>" +
        '<div class="vt-panel-info-item">' +
        '<span class="vt-info-label">Bateria</span>' +
        '<span class="vt-info-value">' +
        (vehicle.battery || "N/A") +
        "</span>" +
        "</div>" +
        "</div>" +
        '<div class="vt-panel-address">' +
        "<strong>Localização:</strong><br>" +
        (vehicle.address || "Carregando endereço...") +
        "</div>" +
        '<div class="vt-panel-coords">' +
        "Lat: " +
        vehicle.latitude.toFixed(6) +
        ", Lng: " +
        vehicle.longitude.toFixed(6) +
        "</div>" +
        "</div>" +
        '<div class="vt-panel-actions">' +
        '<button class="button vt-follow-vehicle" data-vehicle-id="' +
        vehicle.id +
        '">' +
        '<span class="dashicons dashicons-location"></span> Seguir' +
        "</button>" +
        '<button class="button vt-show-history" data-vehicle-id="' +
        vehicle.id +
        '">' +
        '<span class="dashicons dashicons-clock"></span> Histórico' +
        "</button>" +
        '<button class="button vt-send-command" data-vehicle-id="' +
        vehicle.id +
        '" data-command="block">' +
        '<span class="dashicons dashicons-lock"></span> Bloquear' +
        "</button>" +
        "</div>" +
        "</div>"

      // Remove existing panel
      $(".vt-vehicle-panel").remove()

      // Add new panel
      $(".vt-tracking-map").append(html)
    },

    /**
     * Close vehicle panel
     */
    closeVehiclePanel: function () {
      this.selectedVehicle = null
      $(".vt-vehicle-panel").remove()
      $(".vt-vehicle-item").removeClass("active")
    },

    /**
     * Get direction name from degrees
     */
    getDirectionName: (degrees) => {
      var directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
      var index = Math.round(degrees / 45) % 8
      return directions[index]
    },

    /**
     * Filter vehicles by status
     */
    filterVehicles: function (filter) {
      var self = this

      $(".vt-vehicle-item").each(function () {
        var $item = $(this)
        var vehicleId = $item.data("vehicle-id")
        var marker = self.markers[vehicleId]
        var show = true

        if (filter === "online") {
          show =
            $item.find(".vt-vehicle-status").hasClass("online") || $item.find(".vt-vehicle-status").hasClass("moving")
        } else if (filter === "moving") {
          show = $item.find(".vt-vehicle-status").hasClass("moving")
        } else if (filter === "offline") {
          show = $item.find(".vt-vehicle-status").hasClass("offline")
        }

        if (show) {
          $item.show()
          if (marker) marker.setVisible(true)
        } else {
          $item.hide()
          if (marker) marker.setVisible(false)
        }
      })
    },

    /**
     * Search vehicles by plate or driver
     */
    searchVehicles: function (query) {
      var self = this
      query = query.toLowerCase()

      $(".vt-vehicle-item").each(function () {
        var $item = $(this)
        var vehicleId = $item.data("vehicle-id")
        var marker = self.markers[vehicleId]
        var text = $item.text().toLowerCase()
        var show = text.indexOf(query) !== -1

        if (show) {
          $item.show()
          if (marker) marker.setVisible(true)
        } else {
          $item.hide()
          if (marker) marker.setVisible(false)
        }
      })
    },

    /**
     * Fit map to show all vehicles
     */
    fitAllVehicles: function () {
      if (!this.bounds.isEmpty()) {
        this.map.fitBounds(this.bounds)
      }
    },

    /**
     * Toggle follow mode for a vehicle
     */
    toggleFollow: function (vehicleId) {
      if (this.selectedVehicle === vehicleId) {
        this.selectedVehicle = null
        $(".vt-follow-vehicle").text("Seguir")
      } else {
        this.selectedVehicle = vehicleId
        $(".vt-follow-vehicle").text("Parar de seguir")
      }
    },

    /**
     * Show vehicle history/trail
     */
    showVehicleHistory: function (vehicleId) {
      

      // Clear existing polyline
      if (this.polylines[vehicleId]) {
        this.polylines[vehicleId].setMap(null)
      }

      $.ajax({
        url: window.vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_get_vehicle_history",
          vehicle_id: vehicleId,
          hours: 24,
          nonce: window.vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success && response.data.length > 0) {
            var path = response.data.map((point) => new window.google.maps.LatLng(point.latitude, point.longitude))

            this.polylines[vehicleId] = new window.google.maps.Polyline({
              path: path,
              geodesic: true,
              strokeColor: "#3b82f6",
              strokeOpacity: 0.8,
              strokeWeight: 3,
              map: this.map,
            })

            // Fit bounds to show trail
            var bounds = new window.google.maps.LatLngBounds()
            path.forEach((point) => {
              bounds.extend(point)
            })
            this.map.fitBounds(bounds)
          }
        },
      })
    },

    /**
     * Send command to vehicle
     */
    sendCommand: (vehicleId, command) => {
      if (!confirm("Tem certeza que deseja " + (command === "block" ? "bloquear" : "desbloquear") + " este veículo?")) {
        return
      }

      $.ajax({
        url: window.vtAdmin.ajaxUrl,
        type: "POST",
        data: {
          action: "vt_send_vehicle_command",
          vehicle_id: vehicleId,
          command: command,
          nonce: window.vtAdmin.nonce,
        },
        success: (response) => {
          if (response.success) {
            alert("Comando enviado com sucesso!")
          } else {
            alert(response.data.message || "Erro ao enviar comando.")
          }
        },
      })
    },

    /**
     * Start auto-update of vehicle positions
     */
    startAutoUpdate: function () {
      

      // Update every 10 seconds
      this.updateInterval = setInterval(() => {
        this.loadVehicles()
      }, 10000)
    },

    /**
     * Stop auto-update
     */
    stopAutoUpdate: function () {
      if (this.updateInterval) {
        clearInterval(this.updateInterval)
      }
    },
  }
})(window.jQuery)
