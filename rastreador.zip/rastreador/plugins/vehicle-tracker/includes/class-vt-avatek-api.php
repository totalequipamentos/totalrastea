<?php
/**
 * Classe para integração com API Avatek
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Avatek_API {
    
    private $api_url;
    private $api_key;
    private $api_secret;
    private $access_token;
    private $token_expires;
    
    public function __construct() {
        $this->api_url = 'https://api.avatek.com.br/v1';
        $this->api_key = get_option('vt_avatek_api_key', '');
        $this->api_secret = get_option('vt_avatek_api_secret', '');
        $this->access_token = get_transient('vt_avatek_token');
        $this->token_expires = get_transient('vt_avatek_token_expires');
    }
    
    /**
     * Verifica se as credenciais estão configuradas
     */
    public function is_configured() {
        return !empty($this->api_key) && !empty($this->api_secret);
    }
    
    /**
     * Autentica na API e obtém token de acesso
     */
    public function authenticate() {
        if ($this->access_token && $this->token_expires > time()) {
            return true;
        }
        
        $response = wp_remote_post($this->api_url . '/auth/login', array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'api_key' => $this->api_key,
                'api_secret' => $this->api_secret
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            $this->log_error('Auth failed: ' . $response->get_error_message());
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['access_token'])) {
            $this->access_token = $body['access_token'];
            $expires_in = $body['expires_in'] ?? 3600;
            $this->token_expires = time() + $expires_in - 60;
            
            set_transient('vt_avatek_token', $this->access_token, $expires_in - 60);
            set_transient('vt_avatek_token_expires', $this->token_expires, $expires_in - 60);
            
            return true;
        }
        
        $this->log_error('Auth failed: ' . json_encode($body));
        return false;
    }
    
    /**
     * Faz requisição autenticada à API
     */
    private function request($method, $endpoint, $data = null) {
        if (!$this->authenticate()) {
            return false;
        }
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->access_token
            ),
            'timeout' => 30
        );
        
        if ($data && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($this->api_url . $endpoint, $args);
        
        if (is_wp_error($response)) {
            $this->log_error("Request failed ({$endpoint}): " . $response->get_error_message());
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code >= 200 && $code < 300) {
            return $body;
        }
        
        $this->log_error("Request failed ({$endpoint}): " . json_encode($body));
        return false;
    }
    
    /**
     * Lista todos os veículos da conta
     */
    public function get_vehicles() {
        return $this->request('GET', '/vehicles');
    }
    
    /**
     * Obtém informações de um veículo específico
     */
    public function get_vehicle($vehicle_id) {
        return $this->request('GET', '/vehicles/' . $vehicle_id);
    }
    
    /**
     * Obtém última posição de um veículo
     */
    public function get_last_position($vehicle_id) {
        return $this->request('GET', '/vehicles/' . $vehicle_id . '/position');
    }
    
    /**
     * Obtém posições de todos os veículos
     */
    public function get_all_positions() {
        return $this->request('GET', '/positions');
    }
    
    /**
     * Obtém histórico de posições
     */
    public function get_history($vehicle_id, $start_date, $end_date) {
        $params = http_build_query(array(
            'start_date' => $start_date,
            'end_date' => $end_date
        ));
        
        return $this->request('GET', '/vehicles/' . $vehicle_id . '/history?' . $params);
    }
    
    /**
     * Envia comando para o rastreador
     */
    public function send_command($vehicle_id, $command, $params = array()) {
        global $wpdb;
        $db = new VT_Database();
        
        // Mapeia comandos para o formato da API
        $command_map = array(
            'block' => 'output_on',
            'unblock' => 'output_off',
            'locate' => 'position_request',
            'restart' => 'device_restart',
            'config' => 'configure'
        );
        
        $api_command = $command_map[$command] ?? $command;
        
        $data = array(
            'command' => $api_command,
            'parameters' => $params
        );
        
        // Registra o comando no banco
        $wpdb->insert($db->commands_table, array(
            'vehicle_id' => $vehicle_id,
            'user_id' => get_current_user_id(),
            'command' => $command,
            'parameters' => json_encode($params),
            'status' => 'pending',
            'sent_via' => 'avatek'
        ));
        
        $command_id = $wpdb->insert_id;
        
        // Envia para a API
        $result = $this->request('POST', '/vehicles/' . $vehicle_id . '/command', $data);
        
        if ($result) {
            $wpdb->update($db->commands_table, array(
                'status' => 'sent',
                'sent_at' => current_time('mysql'),
                'response' => json_encode($result)
            ), array('id' => $command_id));
            
            return true;
        }
        
        $wpdb->update($db->commands_table, array(
            'status' => 'failed'
        ), array('id' => $command_id));
        
        return false;
    }
    
    /**
     * Obtém alertas
     */
    public function get_alerts($vehicle_id = null, $start_date = null, $end_date = null) {
        $params = array();
        
        if ($vehicle_id) {
            $params['vehicle_id'] = $vehicle_id;
        }
        if ($start_date) {
            $params['start_date'] = $start_date;
        }
        if ($end_date) {
            $params['end_date'] = $end_date;
        }
        
        $query = !empty($params) ? '?' . http_build_query($params) : '';
        
        return $this->request('GET', '/alerts' . $query);
    }
    
    /**
     * Sincroniza todas as posições com o banco local
     */
    public function sync_all_positions() {
        global $wpdb;
        $db = new VT_Database();
        
        $positions = $this->get_all_positions();
        
        if (!$positions || !is_array($positions)) {
            return false;
        }
        
        foreach ($positions as $position) {
            // Encontra o veículo local pelo avatek_id ou IMEI
            $vehicle = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM {$db->vehicles_table} 
                 WHERE avatek_id = %s OR imei = %s",
                $position['vehicle_id'] ?? '',
                $position['imei'] ?? ''
            ));
            
            if (!$vehicle) {
                continue;
            }
            
            // Insere a posição
            $wpdb->insert($db->positions_table, array(
                'vehicle_id' => $vehicle->id,
                'latitude' => $position['latitude'],
                'longitude' => $position['longitude'],
                'altitude' => $position['altitude'] ?? null,
                'speed' => $position['speed'] ?? 0,
                'direction' => $position['direction'] ?? null,
                'ignition' => $position['ignition'] ?? null,
                'battery_voltage' => $position['battery'] ?? null,
                'external_voltage' => $position['external_power'] ?? null,
                'gsm_signal' => $position['gsm_signal'] ?? null,
                'event_type' => $position['event'] ?? 'position',
                'data_source' => 'avatek',
                'device_time' => $position['timestamp'] ?? current_time('mysql'),
                'server_time' => current_time('mysql'),
                'raw_data' => json_encode($position)
            ));
            
            // Atualiza última posição do veículo
            $wpdb->update($db->vehicles_table, array(
                'last_latitude' => $position['latitude'],
                'last_longitude' => $position['longitude'],
                'last_speed' => $position['speed'] ?? 0,
                'last_direction' => $position['direction'] ?? null,
                'last_ignition' => $position['ignition'] ?? null,
                'last_update' => current_time('mysql')
            ), array('id' => $vehicle->id));
        }
        
        return true;
    }
    
    /**
     * Sincroniza lista de veículos da API para o banco local
     */
    public function sync_vehicles() {
        global $wpdb;
        $db = new VT_Database();
        
        $vehicles = $this->get_vehicles();
        
        if (!$vehicles || !is_array($vehicles)) {
            return false;
        }
        
        foreach ($vehicles as $vehicle) {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$db->vehicles_table} WHERE imei = %s",
                $vehicle['imei']
            ));
            
            $data = array(
                'imei' => $vehicle['imei'],
                'plate' => $vehicle['plate'] ?? '',
                'brand' => $vehicle['brand'] ?? '',
                'model' => $vehicle['model'] ?? '',
                'avatek_id' => $vehicle['id'] ?? '',
                'device_model' => $vehicle['device_model'] ?? 'ST8310UM'
            );
            
            if ($existing) {
                $wpdb->update($db->vehicles_table, $data, array('id' => $existing));
            } else {
                $wpdb->insert($db->vehicles_table, $data);
            }
        }
        
        return true;
    }
    
    /**
     * Log de erros
     */
    private function log_error($message) {
        if (WP_DEBUG) {
            error_log('[Vehicle Tracker - Avatek API] ' . $message);
        }
    }
}
