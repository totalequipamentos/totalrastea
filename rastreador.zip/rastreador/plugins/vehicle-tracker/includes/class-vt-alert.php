<?php
/**
 * Classe para gerenciamento de alertas
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Alert {
    
    private $wpdb;
    private $db;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->db = new VT_Database();
    }
    
    /**
     * Obtém alertas
     */
    public function get_all($args = array()) {
        $defaults = array(
            'vehicle_id' => null,
            'type' => null,
            'status' => null,
            'severity' => null,
            'start_date' => null,
            'end_date' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if ($args['vehicle_id']) {
            $where[] = 'a.vehicle_id = %d';
            $values[] = $args['vehicle_id'];
        }
        
        if ($args['type']) {
            $where[] = 'a.type = %s';
            $values[] = $args['type'];
        }
        
        if ($args['status']) {
            $where[] = 'a.status = %s';
            $values[] = $args['status'];
        }
        
        if ($args['severity']) {
            $where[] = 'a.severity = %s';
            $values[] = $args['severity'];
        }
        
        if ($args['start_date']) {
            $where[] = 'a.created_at >= %s';
            $values[] = $args['start_date'];
        }
        
        if ($args['end_date']) {
            $where[] = 'a.created_at <= %s';
            $values[] = $args['end_date'];
        }
        
        $sql = "SELECT a.*, v.plate, v.brand, v.model 
                FROM {$this->db->alerts_table} a 
                LEFT JOIN {$this->db->vehicles_table} v ON a.vehicle_id = v.id 
                WHERE " . implode(' AND ', $where);
        
        $sql .= " ORDER BY a.{$args['orderby']} {$args['order']}";
        $sql .= $this->wpdb->prepare(" LIMIT %d OFFSET %d", $args['limit'], $args['offset']);
        
        if (!empty($values)) {
            $sql = $this->wpdb->prepare($sql, $values);
        }
        
        return $this->wpdb->get_results($sql, ARRAY_A);
    }
    
    /**
     * Obtém um alerta
     */
    public function get($id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT a.*, v.plate, v.brand, v.model 
             FROM {$this->db->alerts_table} a 
             LEFT JOIN {$this->db->vehicles_table} v ON a.vehicle_id = v.id 
             WHERE a.id = %d",
            $id
        ), ARRAY_A);
    }
    
    /**
     * Cria um alerta
     */
    public function create($data) {
        return $this->wpdb->insert($this->db->alerts_table, $data);
    }
    
    /**
     * Marca alerta como lido
     */
    public function mark_as_read($id) {
        return $this->wpdb->update($this->db->alerts_table, array(
            'status' => 'read',
            'read_at' => current_time('mysql')
        ), array('id' => $id));
    }
    
    /**
     * Marca alerta como resolvido
     */
    public function mark_as_resolved($id) {
        return $this->wpdb->update($this->db->alerts_table, array(
            'status' => 'resolved',
            'resolved_at' => current_time('mysql')
        ), array('id' => $id));
    }
    
    /**
     * Descarta alerta
     */
    public function dismiss($id) {
        return $this->wpdb->update($this->db->alerts_table, array(
            'status' => 'dismissed'
        ), array('id' => $id));
    }
    
    /**
     * Conta alertas pendentes
     */
    public function count_pending($vehicle_id = null) {
        $where = "status = 'pending'";
        
        if ($vehicle_id) {
            $where .= $this->wpdb->prepare(" AND vehicle_id = %d", $vehicle_id);
        }
        
        return $this->wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->db->alerts_table} WHERE {$where}"
        );
    }
    
    /**
     * Conta alertas por tipo
     */
    public function count_by_type($period = 'today') {
        $date_filter = $this->get_date_filter($period);
        
        return $this->wpdb->get_results(
            "SELECT type, COUNT(*) as count 
             FROM {$this->db->alerts_table} 
             WHERE {$date_filter} 
             GROUP BY type 
             ORDER BY count DESC",
            ARRAY_A
        );
    }
    
    /**
     * Conta alertas por severidade
     */
    public function count_by_severity($period = 'today') {
        $date_filter = $this->get_date_filter($period);
        
        return $this->wpdb->get_results(
            "SELECT severity, COUNT(*) as count 
             FROM {$this->db->alerts_table} 
             WHERE {$date_filter} 
             GROUP BY severity",
            ARRAY_A
        );
    }
    
    /**
     * Processa alertas pendentes (envia notificações)
     */
    public function process_pending_alerts() {
        $pending = $this->get_all(array(
            'status' => 'pending',
            'limit' => 100
        ));
        
        foreach ($pending as $alert) {
            // Envia notificação por email se for crítico
            if ($alert['severity'] === 'critical') {
                $this->send_email_notification($alert);
            }
            
            // Aqui você pode adicionar outras notificações:
            // - Push notification
            // - SMS
            // - Webhook
            // - etc.
        }
    }
    
    /**
     * Envia notificação por email
     */
    private function send_email_notification($alert) {
        $admin_email = get_option('admin_email');
        $subject = sprintf('[ALERTA] %s - Vehicle Tracker', $alert['title']);
        $message = sprintf(
            "Alerta: %s\n\nVeículo: %s\n\nMensagem: %s\n\nData: %s",
            $alert['title'],
            $alert['plate'] ?? 'N/A',
            $alert['message'],
            $alert['created_at']
        );
        
        wp_mail($admin_email, $subject, $message);
    }
    
    /**
     * Obtém filtro de data
     */
    private function get_date_filter($period) {
        switch ($period) {
            case 'today':
                return "DATE(created_at) = CURDATE()";
            case 'yesterday':
                return "DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case 'week':
                return "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case 'month':
                return "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default:
                return "1=1";
        }
    }
    
    /**
     * Obtém tipos de alerta disponíveis
     */
    public static function get_types() {
        return array(
            'overspeed' => __('Excesso de velocidade', 'vehicle-tracker'),
            'ignition_on' => __('Ignição ligada', 'vehicle-tracker'),
            'ignition_off' => __('Ignição desligada', 'vehicle-tracker'),
            'geofence_enter' => __('Entrada em geocerca', 'vehicle-tracker'),
            'geofence_exit' => __('Saída de geocerca', 'vehicle-tracker'),
            'panic' => __('Botão de pânico', 'vehicle-tracker'),
            'low_battery' => __('Bateria baixa', 'vehicle-tracker'),
            'power_cut' => __('Corte de energia', 'vehicle-tracker'),
            'tamper' => __('Violação', 'vehicle-tracker'),
            'harsh_brake' => __('Frenagem brusca', 'vehicle-tracker'),
            'harsh_acceleration' => __('Aceleração brusca', 'vehicle-tracker'),
            'impact' => __('Impacto/Colisão', 'vehicle-tracker'),
            'idle' => __('Veículo parado/ocioso', 'vehicle-tracker')
        );
    }
}
