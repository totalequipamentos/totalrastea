<?php
/**
 * Classe para endpoints REST API
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_REST_API {
    
    private $namespace = 'vehicle-tracker/v1';
    
    /**
     * Registra rotas da API
     */
    public function register_routes() {
        // Veículos
        register_rest_route($this->namespace, '/vehicles', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_vehicles'),
                'permission_callback' => array($this, 'check_permission')
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'create_vehicle'),
                'permission_callback' => array($this, 'check_admin_permission')
            )
        ));
        
        register_rest_route($this->namespace, '/vehicles/(?P<id>\d+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_vehicle'),
                'permission_callback' => array($this, 'check_permission')
            ),
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => array($this, 'update_vehicle'),
                'permission_callback' => array($this, 'check_admin_permission')
            ),
            array(
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => array($this, 'delete_vehicle'),
                'permission_callback' => array($this, 'check_admin_permission')
            )
        ));
        
        // Posições
        register_rest_route($this->namespace, '/vehicles/(?P<id>\d+)/position', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_vehicle_position'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        register_rest_route($this->namespace, '/vehicles/(?P<id>\d+)/history', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_vehicle_history'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        register_rest_route($this->namespace, '/positions', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_all_positions'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // Comandos
        register_rest_route($this->namespace, '/vehicles/(?P<id>\d+)/command', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'send_command'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));
        
        // Geocercas
        register_rest_route($this->namespace, '/geofences', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_geofences'),
                'permission_callback' => array($this, 'check_permission')
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'create_geofence'),
                'permission_callback' => array($this, 'check_admin_permission')
            )
        ));
        
        register_rest_route($this->namespace, '/geofences/(?P<id>\d+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_geofence'),
                'permission_callback' => array($this, 'check_permission')
            ),
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => array($this, 'update_geofence'),
                'permission_callback' => array($this, 'check_admin_permission')
            ),
            array(
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => array($this, 'delete_geofence'),
                'permission_callback' => array($this, 'check_admin_permission')
            )
        ));
        
        // Alertas
        register_rest_route($this->namespace, '/alerts', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_alerts'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        register_rest_route($this->namespace, '/alerts/(?P<id>\d+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_alert'),
                'permission_callback' => array($this, 'check_permission')
            ),
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => array($this, 'update_alert'),
                'permission_callback' => array($this, 'check_permission')
            )
        ));
        
        // Dashboard stats
        register_rest_route($this->namespace, '/stats', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_stats'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // Webhook para receber dados externos
        register_rest_route($this->namespace, '/webhook/position', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'webhook_position'),
            'permission_callback' => array($this, 'check_webhook_permission')
        ));
    }
    
    /**
     * Verifica permissão básica
     */
    public function check_permission() {
        return current_user_can('read');
    }
    
    /**
     * Verifica permissão de admin
     */
    public function check_admin_permission() {
        return current_user_can('manage_options');
    }
    
    /**
     * Verifica permissão de webhook
     */
    public function check_webhook_permission($request) {
        $api_key = $request->get_header('X-API-Key');
        $expected_key = get_option('vt_webhook_api_key', '');
        
        return !empty($expected_key) && $api_key === $expected_key;
    }
    
    /**
     * GET /vehicles
     */
    public function get_vehicles($request) {
        $vehicle = new VT_Vehicle();
        $args = array(
            'status' => $request->get_param('status'),
            'search' => $request->get_param('search'),
            'limit' => $request->get_param('limit') ?: 100,
            'offset' => $request->get_param('offset') ?: 0
        );
        
        return rest_ensure_response($vehicle->get_all($args));
    }
    
    /**
     * GET /vehicles/{id}
     */
    public function get_vehicle($request) {
        $vehicle = new VT_Vehicle();
        $data = $vehicle->get($request->get_param('id'));
        
        if (!$data) {
            return new WP_Error('not_found', __('Veículo não encontrado', 'vehicle-tracker'), array('status' => 404));
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * POST /vehicles
     */
    public function create_vehicle($request) {
        $vehicle = new VT_Vehicle();
        $result = $vehicle->create($request->get_params());
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return rest_ensure_response(array(
            'id' => $result,
            'message' => __('Veículo cadastrado com sucesso', 'vehicle-tracker')
        ));
    }
    
    /**
     * PUT /vehicles/{id}
     */
    public function update_vehicle($request) {
        $vehicle = new VT_Vehicle();
        $result = $vehicle->update($request->get_param('id'), $request->get_params());
        
        if ($result === false) {
            return new WP_Error('update_failed', __('Erro ao atualizar veículo', 'vehicle-tracker'), array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'message' => __('Veículo atualizado com sucesso', 'vehicle-tracker')
        ));
    }
    
    /**
     * DELETE /vehicles/{id}
     */
    public function delete_vehicle($request) {
        $vehicle = new VT_Vehicle();
        $result = $vehicle->delete($request->get_param('id'));
        
        if (!$result) {
            return new WP_Error('delete_failed', __('Erro ao excluir veículo', 'vehicle-tracker'), array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'message' => __('Veículo excluído com sucesso', 'vehicle-tracker')
        ));
    }
    
    /**
     * GET /vehicles/{id}/position
     */
    public function get_vehicle_position($request) {
        $vehicle = new VT_Vehicle();
        $position = $vehicle->get_last_position($request->get_param('id'));
        
        if (!$position) {
            return new WP_Error('not_found', __('Posição não encontrada', 'vehicle-tracker'), array('status' => 404));
        }
        
        return rest_ensure_response($position);
    }
    
    /**
     * GET /vehicles/{id}/history
     */
    public function get_vehicle_history($request) {
        $vehicle = new VT_Vehicle();
        
        $start_date = $request->get_param('start_date') ?: date('Y-m-d 00:00:00');
        $end_date = $request->get_param('end_date') ?: date('Y-m-d 23:59:59');
        
        $history = $vehicle->get_history($request->get_param('id'), $start_date, $end_date);
        
        return rest_ensure_response($history);
    }
    
    /**
     * GET /positions
     */
    public function get_all_positions($request) {
        $vehicle = new VT_Vehicle();
        $vehicles = $vehicle->get_all(array('status' => 'active'));
        
        $positions = array();
        foreach ($vehicles as $v) {
            if ($v['last_latitude'] && $v['last_longitude']) {
                $positions[] = array(
                    'vehicle_id' => $v['id'],
                    'plate' => $v['plate'],
                    'brand' => $v['brand'],
                    'model' => $v['model'],
                    'latitude' => $v['last_latitude'],
                    'longitude' => $v['last_longitude'],
                    'speed' => $v['last_speed'],
                    'direction' => $v['last_direction'],
                    'ignition' => $v['last_ignition'],
                    'last_update' => $v['last_update'],
                    'is_online' => $v['is_online'],
                    'is_moving' => $v['is_moving'],
                    'status_label' => $v['status_label']
                );
            }
        }
        
        return rest_ensure_response($positions);
    }
    
    /**
     * POST /vehicles/{id}/command
     */
    public function send_command($request) {
        $vehicle_id = $request->get_param('id');
        $command = $request->get_param('command');
        $params = $request->get_param('params') ?: array();
        
        // Tenta via API Avatek primeiro
        $avatek = new VT_Avatek_API();
        if ($avatek->is_configured()) {
            $result = $avatek->send_command($vehicle_id, $command, $params);
            if ($result) {
                return rest_ensure_response(array(
                    'message' => __('Comando enviado via Avatek', 'vehicle-tracker'),
                    'method' => 'avatek'
                ));
            }
        }
        
        // Fallback para TCP
        $tcp = new VT_TCP_Server();
        $result = $tcp->send_command($vehicle_id, $command, $params);
        
        if ($result) {
            return rest_ensure_response(array(
                'message' => __('Comando enviado via TCP', 'vehicle-tracker'),
                'method' => 'tcp'
            ));
        }
        
        return new WP_Error('command_failed', __('Erro ao enviar comando', 'vehicle-tracker'), array('status' => 500));
    }
    
    /**
     * GET /geofences
     */
    public function get_geofences($request) {
        $geofence = new VT_Geofence();
        return rest_ensure_response($geofence->get_all(array(
            'status' => $request->get_param('status')
        )));
    }
    
    /**
     * GET /geofences/{id}
     */
    public function get_geofence($request) {
        $geofence = new VT_Geofence();
        $data = $geofence->get($request->get_param('id'));
        
        if (!$data) {
            return new WP_Error('not_found', __('Geocerca não encontrada', 'vehicle-tracker'), array('status' => 404));
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * POST /geofences
     */
    public function create_geofence($request) {
        $geofence = new VT_Geofence();
        $result = $geofence->create($request->get_params());
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return rest_ensure_response(array(
            'id' => $result,
            'message' => __('Geocerca criada com sucesso', 'vehicle-tracker')
        ));
    }
    
    /**
     * PUT /geofences/{id}
     */
    public function update_geofence($request) {
        $geofence = new VT_Geofence();
        $result = $geofence->update($request->get_param('id'), $request->get_params());
        
        if ($result === false) {
            return new WP_Error('update_failed', __('Erro ao atualizar geocerca', 'vehicle-tracker'), array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'message' => __('Geocerca atualizada com sucesso', 'vehicle-tracker')
        ));
    }
    
    /**
     * DELETE /geofences/{id}
     */
    public function delete_geofence($request) {
        $geofence = new VT_Geofence();
        $result = $geofence->delete($request->get_param('id'));
        
        if (!$result) {
            return new WP_Error('delete_failed', __('Erro ao excluir geocerca', 'vehicle-tracker'), array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'message' => __('Geocerca excluída com sucesso', 'vehicle-tracker')
        ));
    }
    
    /**
     * GET /alerts
     */
    public function get_alerts($request) {
        $alert = new VT_Alert();
        return rest_ensure_response($alert->get_all(array(
            'vehicle_id' => $request->get_param('vehicle_id'),
            'type' => $request->get_param('type'),
            'status' => $request->get_param('status'),
            'severity' => $request->get_param('severity'),
            'start_date' => $request->get_param('start_date'),
            'end_date' => $request->get_param('end_date'),
            'limit' => $request->get_param('limit') ?: 50,
            'offset' => $request->get_param('offset') ?: 0
        )));
    }
    
    /**
     * GET /alerts/{id}
     */
    public function get_alert($request) {
        $alert = new VT_Alert();
        $data = $alert->get($request->get_param('id'));
        
        if (!$data) {
            return new WP_Error('not_found', __('Alerta não encontrado', 'vehicle-tracker'), array('status' => 404));
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * PUT /alerts/{id}
     */
    public function update_alert($request) {
        $alert = new VT_Alert();
        $action = $request->get_param('action');
        $id = $request->get_param('id');
        
        switch ($action) {
            case 'read':
                $result = $alert->mark_as_read($id);
                break;
            case 'resolve':
                $result = $alert->mark_as_resolved($id);
                break;
            case 'dismiss':
                $result = $alert->dismiss($id);
                break;
            default:
                return new WP_Error('invalid_action', __('Ação inválida', 'vehicle-tracker'), array('status' => 400));
        }
        
        if ($result) {
            return rest_ensure_response(array('message' => __('Alerta atualizado', 'vehicle-tracker')));
        }
        
        return new WP_Error('update_failed', __('Erro ao atualizar alerta', 'vehicle-tracker'), array('status' => 500));
    }
    
    /**
     * GET /stats
     */
    public function get_stats($request) {
        $vehicle = new VT_Vehicle();
        $alert = new VT_Alert();
        
        $period = $request->get_param('period') ?: 'today';
        
        return rest_ensure_response(array(
            'vehicles' => $vehicle->count_by_status(),
            'alerts_pending' => $alert->count_pending(),
            'alerts_by_type' => $alert->count_by_type($period),
            'alerts_by_severity' => $alert->count_by_severity($period)
        ));
    }
    
    /**
     * POST /webhook/position
     */
    public function webhook_position($request) {
        $tcp = new VT_TCP_Server();
        $raw_data = $request->get_body();
        
        $result = $tcp->process_data($raw_data);
        
        if ($result) {
            return rest_ensure_response(array('status' => 'ok'));
        }
        
        return new WP_Error('process_failed', __('Erro ao processar dados', 'vehicle-tracker'), array('status' => 500));
    }
}
