<?php
/**
 * Classe para gerenciamento do servidor TCP/UDP
 * Nota: Este é um listener que deve ser executado como processo separado
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_TCP_Server {
    
    private $host;
    private $port;
    private $parser;
    private $db;
    
    public function __construct() {
        $this->host = get_option('vt_tcp_server_host', '0.0.0.0');
        $this->port = get_option('vt_tcp_server_port', '5000');
        $this->parser = new VT_Suntech_Parser();
        $this->db = new VT_Database();
    }
    
    /**
     * Inicia o servidor TCP (modo CLI)
     * Execute via: php wp-content/plugins/vehicle-tracker/cli/start-server.php
     */
    public function start() {
        // Este método deve ser chamado apenas via CLI
        if (php_sapi_name() !== 'cli') {
            return false;
        }
        
        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        
        if ($socket === false) {
            $this->log("Erro ao criar socket: " . socket_strerror(socket_last_error()));
            return false;
        }
        
        socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
        
        if (!socket_bind($socket, $this->host, $this->port)) {
            $this->log("Erro ao vincular socket: " . socket_strerror(socket_last_error()));
            return false;
        }
        
        if (!socket_listen($socket, 50)) {
            $this->log("Erro ao escutar socket: " . socket_strerror(socket_last_error()));
            return false;
        }
        
        $this->log("Servidor TCP iniciado em {$this->host}:{$this->port}");
        
        while (true) {
            $client = socket_accept($socket);
            
            if ($client !== false) {
                $this->handle_client($client);
            }
        }
        
        socket_close($socket);
    }
    
    /**
     * Processa conexão de um cliente (rastreador)
     */
    private function handle_client($client) {
        $client_ip = '';
        socket_getpeername($client, $client_ip);
        
        $this->log("Nova conexão de: {$client_ip}");
        
        // Lê dados do rastreador
        $buffer = '';
        while ($data = socket_read($client, 1024)) {
            $buffer .= $data;
            
            // Verifica se recebeu pacote completo (terminador \r\n ou ;)
            if (strpos($buffer, "\r\n") !== false || substr($buffer, -1) === ';') {
                $this->process_data($buffer, $client);
                $buffer = '';
            }
        }
        
        socket_close($client);
        $this->log("Conexão encerrada: {$client_ip}");
    }
    
    /**
     * Processa dados recebidos do rastreador
     */
    public function process_data($raw_data, $client = null) {
        global $wpdb;
        
        // Remove caracteres de controle
        $raw_data = trim($raw_data);
        
        if (empty($raw_data)) {
            return false;
        }
        
        $this->log("Dados recebidos: {$raw_data}");
        
        // Parse dos dados
        $parsed = $this->parser->parse($raw_data);
        
        if (!$parsed || empty($parsed['imei'])) {
            $this->log("Erro ao processar dados: IMEI não encontrado");
            return false;
        }
        
        // Busca o veículo pelo IMEI
        $vehicle = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->db->vehicles_table} WHERE imei = %s",
            $parsed['imei']
        ));
        
        if (!$vehicle) {
            $this->log("Veículo não encontrado para IMEI: {$parsed['imei']}");
            
            // Opcional: auto-cadastrar veículo desconhecido
            if (get_option('vt_auto_register_vehicles', false)) {
                $this->auto_register_vehicle($parsed['imei']);
            }
            
            return false;
        }
        
        // Salva posição no banco
        $position_data = array(
            'vehicle_id' => $vehicle->id,
            'latitude' => $parsed['latitude'],
            'longitude' => $parsed['longitude'],
            'altitude' => $parsed['altitude'] ?? null,
            'speed' => $parsed['speed'] ?? 0,
            'direction' => $parsed['direction'] ?? null,
            'satellites' => $parsed['satellites'] ?? null,
            'hdop' => $parsed['hdop'] ?? null,
            'ignition' => isset($parsed['ignition']) ? ($parsed['ignition'] ? 1 : 0) : null,
            'input1' => isset($parsed['inputs']['input1']) ? ($parsed['inputs']['input1'] ? 1 : 0) : null,
            'input2' => isset($parsed['inputs']['input2']) ? ($parsed['inputs']['input2'] ? 1 : 0) : null,
            'output1' => isset($parsed['outputs']['output1']) ? ($parsed['outputs']['output1'] ? 1 : 0) : null,
            'output2' => isset($parsed['outputs']['output2']) ? ($parsed['outputs']['output2'] ? 1 : 0) : null,
            'battery_voltage' => $parsed['battery_voltage'] ?? null,
            'external_voltage' => $parsed['external_voltage'] ?? null,
            'odometer' => $parsed['odometer'] ?? null,
            'engine_hours' => $parsed['hour_meter'] ?? null,
            'gsm_signal' => $parsed['gsm_signal'] ?? null,
            'event_code' => $parsed['event_code'] ?? null,
            'event_type' => $parsed['event_type'] ?? 'position',
            'data_source' => 'tcp',
            'device_time' => $parsed['timestamp'] ?? current_time('mysql'),
            'server_time' => current_time('mysql'),
            'raw_data' => $raw_data
        );
        
        $wpdb->insert($this->db->positions_table, $position_data);
        $position_id = $wpdb->insert_id;
        
        // Atualiza última posição do veículo
        $wpdb->update($this->db->vehicles_table, array(
            'last_latitude' => $parsed['latitude'],
            'last_longitude' => $parsed['longitude'],
            'last_speed' => $parsed['speed'] ?? 0,
            'last_direction' => $parsed['direction'] ?? null,
            'last_ignition' => isset($parsed['ignition']) ? ($parsed['ignition'] ? 1 : 0) : null,
            'last_update' => current_time('mysql'),
            'odometer' => $parsed['odometer'] ?? $vehicle->odometer
        ), array('id' => $vehicle->id));
        
        // Processa alertas baseados no evento
        $this->process_alerts($vehicle, $parsed, $position_id);
        
        // Envia ACK para o rastreador se necessário
        if ($client) {
            $ack = $this->create_ack($parsed);
            if ($ack) {
                socket_write($client, $ack, strlen($ack));
            }
        }
        
        return true;
    }
    
    /**
     * Processa alertas baseados nos dados recebidos
     */
    private function process_alerts($vehicle, $parsed, $position_id) {
        global $wpdb;
        
        $alerts = array();
        
        // Alerta de velocidade
        $speed_limit = get_option('vt_speed_limit', 80);
        if ($parsed['speed'] > $speed_limit) {
            $alerts[] = array(
                'type' => 'overspeed',
                'severity' => 'high',
                'title' => sprintf(__('Excesso de velocidade: %d km/h', 'vehicle-tracker'), $parsed['speed']),
                'message' => sprintf(
                    __('O veículo %s excedeu o limite de velocidade. Velocidade registrada: %d km/h (limite: %d km/h)', 'vehicle-tracker'),
                    $vehicle->plate,
                    $parsed['speed'],
                    $speed_limit
                )
            );
        }
        
        // Alerta de ignição
        if ($parsed['event_type'] === 'input_1_on') {
            $alerts[] = array(
                'type' => 'ignition_on',
                'severity' => 'low',
                'title' => __('Ignição ligada', 'vehicle-tracker'),
                'message' => sprintf(__('O veículo %s teve a ignição ligada', 'vehicle-tracker'), $vehicle->plate)
            );
        } elseif ($parsed['event_type'] === 'input_1_off') {
            $alerts[] = array(
                'type' => 'ignition_off',
                'severity' => 'low',
                'title' => __('Ignição desligada', 'vehicle-tracker'),
                'message' => sprintf(__('O veículo %s teve a ignição desligada', 'vehicle-tracker'), $vehicle->plate)
            );
        }
        
        // Alerta de pânico
        if ($parsed['event_type'] === 'panic') {
            $alerts[] = array(
                'type' => 'panic',
                'severity' => 'critical',
                'title' => __('ALERTA DE PÂNICO', 'vehicle-tracker'),
                'message' => sprintf(__('Botão de pânico acionado no veículo %s!', 'vehicle-tracker'), $vehicle->plate)
            );
        }
        
        // Alerta de bateria baixa
        if (isset($parsed['battery_voltage']) && $parsed['battery_voltage'] < 3.5) {
            $alerts[] = array(
                'type' => 'low_battery',
                'severity' => 'medium',
                'title' => __('Bateria backup baixa', 'vehicle-tracker'),
                'message' => sprintf(
                    __('O veículo %s está com bateria backup baixa: %.2fV', 'vehicle-tracker'),
                    $vehicle->plate,
                    $parsed['battery_voltage']
                )
            );
        }
        
        // Verifica geocercas
        $geofences = $wpdb->get_results(
            "SELECT * FROM {$this->db->geofences_table} WHERE status = 'active'"
        );
        
        foreach ($geofences as $geofence) {
            $inside = $this->is_inside_geofence($parsed['latitude'], $parsed['longitude'], $geofence);
            $was_inside = $this->was_inside_geofence($vehicle->id, $geofence->id);
            
            if ($inside && !$was_inside && $geofence->alert_on_enter) {
                $alerts[] = array(
                    'type' => 'geofence_enter',
                    'severity' => 'medium',
                    'title' => sprintf(__('Entrada em geocerca: %s', 'vehicle-tracker'), $geofence->name),
                    'message' => sprintf(
                        __('O veículo %s entrou na geocerca "%s"', 'vehicle-tracker'),
                        $vehicle->plate,
                        $geofence->name
                    ),
                    'geofence_id' => $geofence->id
                );
            } elseif (!$inside && $was_inside && $geofence->alert_on_exit) {
                $alerts[] = array(
                    'type' => 'geofence_exit',
                    'severity' => 'medium',
                    'title' => sprintf(__('Saída de geocerca: %s', 'vehicle-tracker'), $geofence->name),
                    'message' => sprintf(
                        __('O veículo %s saiu da geocerca "%s"', 'vehicle-tracker'),
                        $vehicle->plate,
                        $geofence->name
                    ),
                    'geofence_id' => $geofence->id
                );
            }
        }
        
        // Salva alertas
        foreach ($alerts as $alert) {
            $wpdb->insert($this->db->alerts_table, array(
                'vehicle_id' => $vehicle->id,
                'geofence_id' => $alert['geofence_id'] ?? null,
                'position_id' => $position_id,
                'type' => $alert['type'],
                'severity' => $alert['severity'],
                'title' => $alert['title'],
                'message' => $alert['message'],
                'latitude' => $parsed['latitude'],
                'longitude' => $parsed['longitude'],
                'data' => json_encode($parsed),
                'status' => 'pending'
            ));
        }
    }
    
    /**
     * Verifica se coordenada está dentro de uma geocerca
     */
    private function is_inside_geofence($lat, $lng, $geofence) {
        if ($geofence->type === 'circle') {
            $distance = $this->haversine_distance(
                $lat, $lng,
                $geofence->center_lat, $geofence->center_lng
            );
            return $distance <= $geofence->radius;
        } else {
            // Geocerca poligonal
            $coordinates = json_decode($geofence->coordinates, true);
            return $this->point_in_polygon($lat, $lng, $coordinates);
        }
    }
    
    /**
     * Verifica se o veículo estava dentro da geocerca na última posição
     */
    private function was_inside_geofence($vehicle_id, $geofence_id) {
        global $wpdb;
        
        // Busca último alerta de entrada nesta geocerca
        $last_alert = $wpdb->get_var($wpdb->prepare(
            "SELECT type FROM {$this->db->alerts_table} 
             WHERE vehicle_id = %d AND geofence_id = %d 
             ORDER BY created_at DESC LIMIT 1",
            $vehicle_id, $geofence_id
        ));
        
        return $last_alert === 'geofence_enter';
    }
    
    /**
     * Calcula distância entre dois pontos usando Haversine
     */
    private function haversine_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000; // metros
        
        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lng = deg2rad($lng2 - $lng1);
        
        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lng / 2) * sin($delta_lng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * Verifica se um ponto está dentro de um polígono
     */
    private function point_in_polygon($lat, $lng, $polygon) {
        $n = count($polygon);
        $inside = false;
        
        for ($i = 0, $j = $n - 1; $i < $n; $j = $i++) {
            $xi = $polygon[$i]['lat'];
            $yi = $polygon[$i]['lng'];
            $xj = $polygon[$j]['lat'];
            $yj = $polygon[$j]['lng'];
            
            if ((($yi > $lng) != ($yj > $lng)) &&
                ($lat < ($xj - $xi) * ($lng - $yi) / ($yj - $yi) + $xi)) {
                $inside = !$inside;
            }
        }
        
        return $inside;
    }
    
    /**
     * Cria mensagem ACK para o rastreador
     */
    private function create_ack($parsed) {
        // Alguns rastreadores Suntech requerem ACK
        return "ACK;{$parsed['imei']}\r\n";
    }
    
    /**
     * Envia comando para um rastreador via TCP
     */
    public function send_command($vehicle_id, $command, $params = array()) {
        global $wpdb;
        
        $vehicle = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->db->vehicles_table} WHERE id = %d",
            $vehicle_id
        ));
        
        if (!$vehicle) {
            return false;
        }
        
        $cmd = $this->parser->create_command($vehicle->imei, $command, $params);
        
        if (!$cmd) {
            return false;
        }
        
        // Registra o comando
        $wpdb->insert($this->db->commands_table, array(
            'vehicle_id' => $vehicle_id,
            'user_id' => get_current_user_id(),
            'command' => $command,
            'parameters' => json_encode($params),
            'raw_command' => $cmd,
            'status' => 'pending',
            'sent_via' => 'tcp'
        ));
        
        $command_id = $wpdb->insert_id;
        
        // Aqui você implementaria a lógica de envio
        // Pode ser via socket direto, fila de mensagens, etc.
        
        // Por enquanto, apenas marca como enviado
        $wpdb->update($this->db->commands_table, array(
            'status' => 'sent',
            'sent_at' => current_time('mysql')
        ), array('id' => $command_id));
        
        return true;
    }
    
    /**
     * Auto-registra veículo desconhecido
     */
    private function auto_register_vehicle($imei) {
        global $wpdb;
        
        $wpdb->insert($this->db->vehicles_table, array(
            'imei' => $imei,
            'plate' => 'AUTO-' . substr($imei, -6),
            'device_model' => 'ST8310UM',
            'status' => 'inactive'
        ));
        
        $this->log("Veículo auto-registrado: IMEI {$imei}");
    }
    
    /**
     * Log de mensagens
     */
    private function log($message) {
        if (WP_DEBUG) {
            error_log('[Vehicle Tracker - TCP Server] ' . $message);
        }
    }
}
