<?php
/**
 * Classe para gerenciamento do banco de dados
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Database {
    
    private $wpdb;
    private $charset_collate;
    
    // Prefixo das tabelas
    public $prefix;
    
    // Nomes das tabelas
    public $vehicles_table;
    public $positions_table;
    public $geofences_table;
    public $alerts_table;
    public $commands_table;
    public $users_table;
    
    public function __construct() {
        global $wpdb;
        
        $this->wpdb = $wpdb;
        $this->charset_collate = $wpdb->get_charset_collate();
        $this->prefix = $wpdb->prefix . 'vt_';
        
        // Define nomes das tabelas
        $this->vehicles_table = $this->prefix . 'vehicles';
        $this->positions_table = $this->prefix . 'positions';
        $this->geofences_table = $this->prefix . 'geofences';
        $this->alerts_table = $this->prefix . 'alerts';
        $this->commands_table = $this->prefix . 'commands';
        $this->users_table = $this->prefix . 'users';
    }
    
    /**
     * Cria todas as tabelas do plugin
     */
    public function create_tables() {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $this->create_vehicles_table();
        $this->create_positions_table();
        $this->create_geofences_table();
        $this->create_alerts_table();
        $this->create_commands_table();
        $this->create_users_table();
    }
    
    /**
     * Tabela de veículos
     */
    private function create_vehicles_table() {
        $sql = "CREATE TABLE {$this->vehicles_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            imei varchar(20) NOT NULL,
            plate varchar(20) NOT NULL,
            brand varchar(100) DEFAULT NULL,
            model varchar(100) DEFAULT NULL,
            year int(4) DEFAULT NULL,
            color varchar(50) DEFAULT NULL,
            chassis varchar(50) DEFAULT NULL,
            renavam varchar(20) DEFAULT NULL,
            device_model varchar(50) DEFAULT 'ST8310UM',
            device_serial varchar(50) DEFAULT NULL,
            sim_iccid varchar(30) DEFAULT NULL,
            sim_phone varchar(20) DEFAULT NULL,
            sim_operator varchar(50) DEFAULT 'TIM',
            avatek_id varchar(50) DEFAULT NULL,
            status enum('active','inactive','blocked','maintenance') DEFAULT 'active',
            icon varchar(50) DEFAULT 'car',
            odometer decimal(12,2) DEFAULT 0,
            fuel_capacity decimal(6,2) DEFAULT NULL,
            last_latitude decimal(10,8) DEFAULT NULL,
            last_longitude decimal(11,8) DEFAULT NULL,
            last_speed decimal(6,2) DEFAULT NULL,
            last_direction int(3) DEFAULT NULL,
            last_ignition tinyint(1) DEFAULT NULL,
            last_update datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY imei (imei),
            KEY plate (plate),
            KEY user_id (user_id),
            KEY avatek_id (avatek_id),
            KEY status (status)
        ) {$this->charset_collate};";
        
        dbDelta($sql);
    }
    
    /**
     * Tabela de posições (telemetria)
     */
    private function create_positions_table() {
        $sql = "CREATE TABLE {$this->positions_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            vehicle_id bigint(20) UNSIGNED NOT NULL,
            latitude decimal(10,8) NOT NULL,
            longitude decimal(11,8) NOT NULL,
            altitude decimal(8,2) DEFAULT NULL,
            speed decimal(6,2) DEFAULT 0,
            direction int(3) DEFAULT NULL,
            satellites int(2) DEFAULT NULL,
            hdop decimal(4,2) DEFAULT NULL,
            ignition tinyint(1) DEFAULT NULL,
            input1 tinyint(1) DEFAULT NULL,
            input2 tinyint(1) DEFAULT NULL,
            output1 tinyint(1) DEFAULT NULL,
            output2 tinyint(1) DEFAULT NULL,
            battery_voltage decimal(5,2) DEFAULT NULL,
            external_voltage decimal(5,2) DEFAULT NULL,
            odometer decimal(12,2) DEFAULT NULL,
            engine_hours decimal(10,2) DEFAULT NULL,
            fuel_level decimal(5,2) DEFAULT NULL,
            temperature decimal(5,2) DEFAULT NULL,
            gsm_signal int(3) DEFAULT NULL,
            event_code varchar(10) DEFAULT NULL,
            event_type varchar(50) DEFAULT NULL,
            address text DEFAULT NULL,
            raw_data text DEFAULT NULL,
            data_source enum('tcp','avatek','manual') DEFAULT 'tcp',
            device_time datetime NOT NULL,
            server_time datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY vehicle_id (vehicle_id),
            KEY device_time (device_time),
            KEY event_type (event_type),
            KEY lat_lng (latitude, longitude)
        ) {$this->charset_collate};";
        
        dbDelta($sql);
    }
    
    /**
     * Tabela de geocercas
     */
    private function create_geofences_table() {
        $sql = "CREATE TABLE {$this->geofences_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            name varchar(100) NOT NULL,
            description text DEFAULT NULL,
            type enum('circle','polygon') DEFAULT 'circle',
            center_lat decimal(10,8) DEFAULT NULL,
            center_lng decimal(11,8) DEFAULT NULL,
            radius decimal(10,2) DEFAULT NULL,
            coordinates longtext DEFAULT NULL,
            color varchar(7) DEFAULT '#3388ff',
            fill_color varchar(7) DEFAULT '#3388ff',
            fill_opacity decimal(3,2) DEFAULT 0.2,
            alert_on_enter tinyint(1) DEFAULT 1,
            alert_on_exit tinyint(1) DEFAULT 1,
            status enum('active','inactive') DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY status (status)
        ) {$this->charset_collate};";
        
        dbDelta($sql);
    }
    
    /**
     * Tabela de alertas
     */
    private function create_alerts_table() {
        $sql = "CREATE TABLE {$this->alerts_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            vehicle_id bigint(20) UNSIGNED NOT NULL,
            geofence_id bigint(20) UNSIGNED DEFAULT NULL,
            position_id bigint(20) UNSIGNED DEFAULT NULL,
            type varchar(50) NOT NULL,
            severity enum('low','medium','high','critical') DEFAULT 'medium',
            title varchar(200) NOT NULL,
            message text DEFAULT NULL,
            latitude decimal(10,8) DEFAULT NULL,
            longitude decimal(11,8) DEFAULT NULL,
            address text DEFAULT NULL,
            data longtext DEFAULT NULL,
            status enum('pending','read','resolved','dismissed') DEFAULT 'pending',
            read_at datetime DEFAULT NULL,
            resolved_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY vehicle_id (vehicle_id),
            KEY type (type),
            KEY status (status),
            KEY severity (severity),
            KEY created_at (created_at)
        ) {$this->charset_collate};";
        
        dbDelta($sql);
    }
    
    /**
     * Tabela de comandos enviados
     */
    private function create_commands_table() {
        $sql = "CREATE TABLE {$this->commands_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            vehicle_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            command varchar(100) NOT NULL,
            parameters text DEFAULT NULL,
            raw_command text DEFAULT NULL,
            status enum('pending','sent','delivered','executed','failed') DEFAULT 'pending',
            response text DEFAULT NULL,
            sent_via enum('tcp','avatek','sms') DEFAULT 'avatek',
            sent_at datetime DEFAULT NULL,
            delivered_at datetime DEFAULT NULL,
            executed_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY vehicle_id (vehicle_id),
            KEY status (status),
            KEY created_at (created_at)
        ) {$this->charset_collate};";
        
        dbDelta($sql);
    }
    
    /**
     * Tabela de usuários da plataforma (clientes/gestores)
     */
    private function create_users_table() {
        $sql = "CREATE TABLE {$this->users_table} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            wp_user_id bigint(20) UNSIGNED DEFAULT NULL,
            company_name varchar(200) DEFAULT NULL,
            contact_name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20) DEFAULT NULL,
            document varchar(20) DEFAULT NULL,
            address text DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            state varchar(2) DEFAULT NULL,
            zip_code varchar(10) DEFAULT NULL,
            plan enum('basic','professional','enterprise') DEFAULT 'basic',
            max_vehicles int(5) DEFAULT 5,
            status enum('active','inactive','suspended') DEFAULT 'active',
            api_key varchar(64) DEFAULT NULL,
            api_secret varchar(64) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY email (email),
            KEY wp_user_id (wp_user_id),
            KEY status (status)
        ) {$this->charset_collate};";
        
        dbDelta($sql);
    }
    
    /**
     * Remove todas as tabelas (uso na desinstalação)
     */
    public function drop_tables() {
        $tables = array(
            $this->commands_table,
            $this->alerts_table,
            $this->positions_table,
            $this->geofences_table,
            $this->vehicles_table,
            $this->users_table
        );
        
        foreach ($tables as $table) {
            $this->wpdb->query("DROP TABLE IF EXISTS {$table}");
        }
    }
}
