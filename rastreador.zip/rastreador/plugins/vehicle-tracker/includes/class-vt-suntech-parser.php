<?php
/**
 * Parser para protocolo Suntech ST8310UM
 * Decodifica os pacotes de dados enviados pelo rastreador
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Suntech_Parser {
    
    // Tipos de mensagem Suntech
    const MSG_STATUS = 'STT';      // Status normal
    const MSG_EMERGENCY = 'EMG';   // Emergência
    const MSG_EVENT = 'EVT';       // Evento
    const MSG_ALERT = 'ALT';       // Alerta
    const MSG_UNIVERSAL = 'UEX';   // Universal (ST8310)
    
    // Eventos comuns
    const EVENT_INPUT_1_ON = '1';
    const EVENT_INPUT_1_OFF = '2';
    const EVENT_INPUT_2_ON = '3';
    const EVENT_INPUT_2_OFF = '4';
    const EVENT_OVERSPEED = '5';
    const EVENT_IDLING = '6';
    const EVENT_GEOFENCE_IN = '7';
    const EVENT_GEOFENCE_OUT = '8';
    const EVENT_POWER_ON = '9';
    const EVENT_POWER_OFF = '10';
    const EVENT_PANIC = '11';
    const EVENT_HARSH_BRAKE = '20';
    const EVENT_HARSH_ACCEL = '21';
    const EVENT_HARSH_TURN = '22';
    
    /**
     * Processa um pacote de dados bruto do rastreador
     */
    public function parse($raw_data) {
        // Remove caracteres de controle
        $raw_data = trim($raw_data);
        
        // Identifica o tipo de mensagem
        $msg_type = substr($raw_data, 0, 3);
        
        switch ($msg_type) {
            case self::MSG_STATUS:
                return $this->parse_status($raw_data);
            case self::MSG_EMERGENCY:
                return $this->parse_emergency($raw_data);
            case self::MSG_EVENT:
                return $this->parse_event($raw_data);
            case self::MSG_ALERT:
                return $this->parse_alert($raw_data);
            case self::MSG_UNIVERSAL:
                return $this->parse_universal($raw_data);
            default:
                return $this->parse_generic($raw_data);
        }
    }
    
    /**
     * Parse de mensagem de status (STT)
     * Formato: STT;IMEI;[DevID];[SwVer];[DateTime];[Cell];[Lat];[Long];[Speed];[Course];[Satellites];[Fix];[Inputs];[AnalogIn1];[AnalogIn2];[DigOut];[MsgType];[EventCode];[Odometer];[HourMeter]
     */
    private function parse_status($data) {
        $parts = explode(';', $data);
        
        if (count($parts) < 10) {
            return false;
        }
        
        $result = array(
            'msg_type' => 'status',
            'raw_data' => $data,
            'imei' => $this->clean_field($parts[1] ?? ''),
            'device_id' => $this->clean_field($parts[2] ?? ''),
            'sw_version' => $this->clean_field($parts[3] ?? ''),
            'timestamp' => $this->parse_datetime($parts[4] ?? ''),
            'cell_id' => $this->clean_field($parts[5] ?? ''),
            'latitude' => $this->parse_coordinate($parts[6] ?? '', 'lat'),
            'longitude' => $this->parse_coordinate($parts[7] ?? '', 'lon'),
            'speed' => floatval($parts[8] ?? 0),
            'direction' => intval($parts[9] ?? 0),
            'satellites' => intval($parts[10] ?? 0),
            'gps_fix' => $this->parse_gps_fix($parts[11] ?? ''),
            'inputs' => $this->parse_io($parts[12] ?? ''),
            'analog_in1' => floatval($parts[13] ?? 0),
            'analog_in2' => floatval($parts[14] ?? 0),
            'outputs' => $this->parse_io($parts[15] ?? ''),
            'event_code' => $this->clean_field($parts[17] ?? ''),
            'odometer' => floatval($parts[18] ?? 0),
            'hour_meter' => floatval($parts[19] ?? 0)
        );
        
        // Calcula valores derivados
        $result['ignition'] = ($result['inputs']['input1'] ?? false);
        $result['external_voltage'] = $result['analog_in1'] / 100; // Converte para volts
        $result['battery_voltage'] = $result['analog_in2'] / 100;
        
        return $result;
    }
    
    /**
     * Parse de mensagem de emergência (EMG)
     */
    private function parse_emergency($data) {
        $parts = explode(';', $data);
        
        $result = $this->parse_status($data);
        $result['msg_type'] = 'emergency';
        $result['emergency_type'] = $this->clean_field($parts[17] ?? '');
        
        return $result;
    }
    
    /**
     * Parse de mensagem de evento (EVT)
     */
    private function parse_event($data) {
        $parts = explode(';', $data);
        
        $result = $this->parse_status($data);
        $result['msg_type'] = 'event';
        $result['event_type'] = $this->get_event_description($parts[17] ?? '');
        
        return $result;
    }
    
    /**
     * Parse de mensagem de alerta (ALT)
     */
    private function parse_alert($data) {
        $parts = explode(';', $data);
        
        $result = $this->parse_status($data);
        $result['msg_type'] = 'alert';
        $result['alert_type'] = $this->clean_field($parts[17] ?? '');
        
        return $result;
    }
    
    /**
     * Parse de mensagem universal ST8310 (UEX)
     * Formato estendido com mais campos
     */
    private function parse_universal($data) {
        $parts = explode(';', $data);
        
        $result = array(
            'msg_type' => 'universal',
            'raw_data' => $data,
            'imei' => $this->clean_field($parts[1] ?? ''),
            'device_id' => $this->clean_field($parts[2] ?? ''),
            'model' => $this->clean_field($parts[3] ?? ''),
            'sw_version' => $this->clean_field($parts[4] ?? ''),
            'timestamp' => $this->parse_datetime($parts[5] ?? ''),
            'cell_id' => $this->clean_field($parts[6] ?? ''),
            'latitude' => $this->parse_coordinate($parts[7] ?? '', 'lat'),
            'longitude' => $this->parse_coordinate($parts[8] ?? '', 'lon'),
            'speed' => floatval($parts[9] ?? 0),
            'direction' => intval($parts[10] ?? 0),
            'satellites' => intval($parts[11] ?? 0),
            'gps_fix' => $this->parse_gps_fix($parts[12] ?? ''),
            'hdop' => floatval($parts[13] ?? 0),
            'altitude' => floatval($parts[14] ?? 0),
            'inputs' => $this->parse_io($parts[15] ?? ''),
            'outputs' => $this->parse_io($parts[16] ?? ''),
            'analog_in1' => floatval($parts[17] ?? 0),
            'analog_in2' => floatval($parts[18] ?? 0),
            'analog_in3' => floatval($parts[19] ?? 0),
            'event_code' => $this->clean_field($parts[20] ?? ''),
            'odometer' => floatval($parts[21] ?? 0),
            'hour_meter' => floatval($parts[22] ?? 0),
            'gsm_signal' => intval($parts[23] ?? 0),
            'battery_voltage' => floatval($parts[24] ?? 0) / 100,
            'external_voltage' => floatval($parts[25] ?? 0) / 100,
            'driver_id' => $this->clean_field($parts[26] ?? ''),
            'temperature' => floatval($parts[27] ?? 0)
        );
        
        $result['ignition'] = ($result['inputs']['input1'] ?? false);
        $result['event_type'] = $this->get_event_description($result['event_code']);
        
        return $result;
    }
    
    /**
     * Parse genérico para formatos não reconhecidos
     */
    private function parse_generic($data) {
        $parts = explode(';', $data);
        
        return array(
            'msg_type' => 'unknown',
            'raw_data' => $data,
            'parts' => $parts,
            'imei' => $this->extract_imei($data)
        );
    }
    
    /**
     * Converte string de data/hora para formato MySQL
     */
    private function parse_datetime($datetime_str) {
        // Formato Suntech: YYYYMMDD;HH:MM:SS ou YYYYMMDDHHMMSS
        $datetime_str = str_replace(array(';', ':', ' '), '', $datetime_str);
        
        if (strlen($datetime_str) >= 14) {
            $year = substr($datetime_str, 0, 4);
            $month = substr($datetime_str, 4, 2);
            $day = substr($datetime_str, 6, 2);
            $hour = substr($datetime_str, 8, 2);
            $minute = substr($datetime_str, 10, 2);
            $second = substr($datetime_str, 12, 2);
            
            return "{$year}-{$month}-{$day} {$hour}:{$minute}:{$second}";
        }
        
        return current_time('mysql');
    }
    
    /**
     * Converte coordenada do formato Suntech para decimal
     */
    private function parse_coordinate($coord_str, $type = 'lat') {
        // Remove espaços e caracteres especiais
        $coord_str = trim($coord_str);
        
        // Verifica se já está em formato decimal
        if (is_numeric($coord_str)) {
            return floatval($coord_str);
        }
        
        // Formato: -23.550520 ou -23 33.0312
        $parts = preg_split('/[\s,]+/', $coord_str);
        
        if (count($parts) == 1) {
            return floatval($parts[0]);
        }
        
        $degrees = floatval($parts[0]);
        $minutes = floatval($parts[1] ?? 0);
        
        $decimal = abs($degrees) + ($minutes / 60);
        
        return $degrees < 0 ? -$decimal : $decimal;
    }
    
    /**
     * Parse do status de GPS Fix
     */
    private function parse_gps_fix($fix_str) {
        $fix_map = array(
            '1' => 'no_fix',
            '2' => '2d_fix',
            '3' => '3d_fix'
        );
        
        return $fix_map[$fix_str] ?? 'unknown';
    }
    
    /**
     * Parse de entradas/saídas digitais
     */
    private function parse_io($io_str) {
        $io_str = str_pad($io_str, 8, '0', STR_PAD_LEFT);
        
        return array(
            'input1' => (bool)($io_str[7] ?? 0),
            'input2' => (bool)($io_str[6] ?? 0),
            'input3' => (bool)($io_str[5] ?? 0),
            'input4' => (bool)($io_str[4] ?? 0),
            'output1' => (bool)($io_str[3] ?? 0),
            'output2' => (bool)($io_str[2] ?? 0),
            'output3' => (bool)($io_str[1] ?? 0),
            'output4' => (bool)($io_str[0] ?? 0)
        );
    }
    
    /**
     * Limpa campo removendo caracteres inválidos
     */
    private function clean_field($field) {
        return trim(preg_replace('/[^\w\d\-_.]/', '', $field));
    }
    
    /**
     * Extrai IMEI de uma string de dados
     */
    private function extract_imei($data) {
        if (preg_match('/\d{15}/', $data, $matches)) {
            return $matches[0];
        }
        return '';
    }
    
    /**
     * Retorna descrição do evento
     */
    private function get_event_description($event_code) {
        $events = array(
            '1' => 'input_1_on',
            '2' => 'input_1_off',
            '3' => 'input_2_on',
            '4' => 'input_2_off',
            '5' => 'overspeed',
            '6' => 'idling',
            '7' => 'geofence_enter',
            '8' => 'geofence_exit',
            '9' => 'power_on',
            '10' => 'power_off',
            '11' => 'panic',
            '20' => 'harsh_brake',
            '21' => 'harsh_acceleration',
            '22' => 'harsh_turn',
            '23' => 'impact',
            '30' => 'tamper_alert',
            '31' => 'low_battery',
            '32' => 'gps_antenna_open',
            '33' => 'gps_antenna_short'
        );
        
        return $events[$event_code] ?? 'position';
    }
    
    /**
     * Cria comando para enviar ao rastreador
     */
    public function create_command($imei, $command, $params = array()) {
        $commands = array(
            'block' => "CMD;{$imei};02;Output1;1",
            'unblock' => "CMD;{$imei};02;Output1;0",
            'locate' => "CMD;{$imei};02;Position",
            'restart' => "CMD;{$imei};02;Reset",
            'set_interval' => "CMD;{$imei};02;ReportInterval;" . ($params['interval'] ?? 60),
            'set_timezone' => "CMD;{$imei};02;TimeZone;" . ($params['timezone'] ?? -3),
            'set_apn' => "CMD;{$imei};02;APN;" . ($params['apn'] ?? 'timbrasil.br'),
            'set_server' => "CMD;{$imei};02;Server;" . ($params['host'] ?? '') . ";" . ($params['port'] ?? '5000'),
            'set_speed_limit' => "CMD;{$imei};02;SpeedLimit;" . ($params['speed'] ?? 120)
        );
        
        return $commands[$command] ?? null;
    }
    
    /**
     * Valida checksum de um pacote (se aplicável)
     */
    public function validate_checksum($data) {
        // Alguns protocolos Suntech usam checksum no final
        // Implementação depende da versão do firmware
        return true;
    }
}
