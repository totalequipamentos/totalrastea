<?php
/**
 * Classe para gerenciamento de geocercas
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Geofence {
    
    private $wpdb;
    private $db;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->db = new VT_Database();
    }
    
    /**
     * Obtém todas as geocercas
     */
    public function get_all($args = array()) {
        $defaults = array(
            'user_id' => null,
            'status' => null,
            'orderby' => 'name',
            'order' => 'ASC'
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if ($args['user_id']) {
            $where[] = 'user_id = %d';
            $values[] = $args['user_id'];
        }
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $values[] = $args['status'];
        }
        
        $sql = "SELECT * FROM {$this->db->geofences_table} WHERE " . implode(' AND ', $where);
        $sql .= " ORDER BY {$args['orderby']} {$args['order']}";
        
        if (!empty($values)) {
            $sql = $this->wpdb->prepare($sql, $values);
        }
        
        return $this->wpdb->get_results($sql, ARRAY_A);
    }
    
    /**
     * Obtém uma geocerca
     */
    public function get($id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->db->geofences_table} WHERE id = %d",
            $id
        ), ARRAY_A);
    }
    
    /**
     * Cria uma geocerca
     */
    public function create($data) {
        $defaults = array(
            'user_id' => null,
            'name' => '',
            'description' => '',
            'type' => 'circle',
            'center_lat' => null,
            'center_lng' => null,
            'radius' => null,
            'coordinates' => null,
            'color' => '#3388ff',
            'fill_color' => '#3388ff',
            'fill_opacity' => 0.2,
            'alert_on_enter' => 1,
            'alert_on_exit' => 1,
            'status' => 'active'
        );
        
        $data = wp_parse_args($data, $defaults);
        
        if (empty($data['name'])) {
            return new WP_Error('invalid_name', __('Nome é obrigatório', 'vehicle-tracker'));
        }
        
        if ($data['type'] === 'circle') {
            if (!$data['center_lat'] || !$data['center_lng'] || !$data['radius']) {
                return new WP_Error('invalid_circle', __('Centro e raio são obrigatórios para cercas circulares', 'vehicle-tracker'));
            }
        } else {
            if (empty($data['coordinates'])) {
                return new WP_Error('invalid_polygon', __('Coordenadas são obrigatórias para cercas poligonais', 'vehicle-tracker'));
            }
            
            if (is_array($data['coordinates'])) {
                $data['coordinates'] = json_encode($data['coordinates']);
            }
        }
        
        $result = $this->wpdb->insert($this->db->geofences_table, $data);
        
        if ($result) {
            return $this->wpdb->insert_id;
        }
        
        return new WP_Error('insert_failed', __('Erro ao criar geocerca', 'vehicle-tracker'));
    }
    
    /**
     * Atualiza uma geocerca
     */
    public function update($id, $data) {
        $allowed = array(
            'name', 'description', 'type', 'center_lat', 'center_lng',
            'radius', 'coordinates', 'color', 'fill_color', 'fill_opacity',
            'alert_on_enter', 'alert_on_exit', 'status'
        );
        
        $update_data = array_intersect_key($data, array_flip($allowed));
        
        if (isset($update_data['coordinates']) && is_array($update_data['coordinates'])) {
            $update_data['coordinates'] = json_encode($update_data['coordinates']);
        }
        
        return $this->wpdb->update($this->db->geofences_table, $update_data, array('id' => $id));
    }
    
    /**
     * Exclui uma geocerca
     */
    public function delete($id) {
        return $this->wpdb->delete($this->db->geofences_table, array('id' => $id));
    }
    
    /**
     * Verifica quais veículos estão dentro de uma geocerca
     */
    public function get_vehicles_inside($geofence_id) {
        $geofence = $this->get($geofence_id);
        
        if (!$geofence) {
            return array();
        }
        
        $vehicle_model = new VT_Vehicle();
        $vehicles = $vehicle_model->get_all(array('status' => 'active'));
        
        $inside = array();
        
        foreach ($vehicles as $vehicle) {
            if ($vehicle['last_latitude'] && $vehicle['last_longitude']) {
                if ($this->is_inside($vehicle['last_latitude'], $vehicle['last_longitude'], $geofence)) {
                    $inside[] = $vehicle;
                }
            }
        }
        
        return $inside;
    }
    
    /**
     * Verifica se um ponto está dentro da geocerca
     */
    public function is_inside($lat, $lng, $geofence) {
        if ($geofence['type'] === 'circle') {
            $distance = $this->haversine_distance(
                $lat, $lng,
                $geofence['center_lat'], $geofence['center_lng']
            );
            return $distance <= $geofence['radius'];
        } else {
            $coordinates = json_decode($geofence['coordinates'], true);
            return $this->point_in_polygon($lat, $lng, $coordinates);
        }
    }
    
    /**
     * Calcula distância usando Haversine
     */
    private function haversine_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000;
        
        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lng = deg2rad($lng2 - $lng1);
        
        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lng / 2) * sin($delta_lng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * Verifica se ponto está em polígono
     */
    private function point_in_polygon($lat, $lng, $polygon) {
        $n = count($polygon);
        $inside = false;
        
        for ($i = 0, $j = $n - 1; $i < $n; $j = $i++) {
            $xi = $polygon[$i]['lat'];
            $yi = $polygon[$i]['lng'];
            $xj = $polygon[$j]['lat'];
            $yj = $polygon[$j]['lng'];
            
            if ((($yi > $lng) != ($yj > $lng)) &&
                ($lat < ($xj - $xi) * ($lng - $yi) / ($yj - $yi) + $xi)) {
                $inside = !$inside;
            }
        }
        
        return $inside;
    }
}
