<?php
/**
 * Classe para gerenciamento de veículos
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Vehicle {
    
    private $wpdb;
    private $db;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->db = new VT_Database();
    }
    
    /**
     * Obtém todos os veículos
     */
    public function get_all($args = array()) {
        $defaults = array(
            'user_id' => null,
            'status' => null,
            'search' => null,
            'orderby' => 'plate',
            'order' => 'ASC',
            'limit' => null,
            'offset' => 0
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if ($args['user_id']) {
            $where[] = 'user_id = %d';
            $values[] = $args['user_id'];
        }
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $values[] = $args['status'];
        }
        
        if ($args['search']) {
            $where[] = '(plate LIKE %s OR imei LIKE %s OR brand LIKE %s OR model LIKE %s)';
            $search = '%' . $this->wpdb->esc_like($args['search']) . '%';
            $values[] = $search;
            $values[] = $search;
            $values[] = $search;
            $values[] = $search;
        }
        
        $sql = "SELECT * FROM {$this->db->vehicles_table} WHERE " . implode(' AND ', $where);
        
        // Ordenação
        $allowed_orderby = array('plate', 'brand', 'model', 'status', 'last_update', 'created_at');
        $orderby = in_array($args['orderby'], $allowed_orderby) ? $args['orderby'] : 'plate';
        $order = strtoupper($args['order']) === 'DESC' ? 'DESC' : 'ASC';
        $sql .= " ORDER BY {$orderby} {$order}";
        
        // Limit
        if ($args['limit']) {
            $sql .= $this->wpdb->prepare(' LIMIT %d OFFSET %d', $args['limit'], $args['offset']);
        }
        
        if (!empty($values)) {
            $sql = $this->wpdb->prepare($sql, $values);
        }
        
        $vehicles = $this->wpdb->get_results($sql, ARRAY_A);
        
        // Adiciona status calculado
        foreach ($vehicles as &$vehicle) {
            $vehicle['is_online'] = $this->is_online($vehicle['last_update']);
            $vehicle['is_moving'] = $vehicle['is_online'] && floatval($vehicle['last_speed']) > 0;
            $vehicle['status_label'] = $this->get_status_label($vehicle);
        }
        
        return $vehicles;
    }
    
    /**
     * Obtém um veículo específico
     */
    public function get($id) {
        $vehicle = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->db->vehicles_table} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if ($vehicle) {
            $vehicle['is_online'] = $this->is_online($vehicle['last_update']);
            $vehicle['is_moving'] = $vehicle['is_online'] && floatval($vehicle['last_speed']) > 0;
            $vehicle['status_label'] = $this->get_status_label($vehicle);
        }
        
        return $vehicle;
    }
    
    /**
     * Obtém veículo por IMEI
     */
    public function get_by_imei($imei) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->db->vehicles_table} WHERE imei = %s",
            $imei
        ), ARRAY_A);
    }
    
    /**
     * Cria um novo veículo
     */
    public function create($data) {
        $defaults = array(
            'user_id' => null,
            'imei' => '',
            'plate' => '',
            'brand' => '',
            'model' => '',
            'year' => null,
            'color' => '',
            'chassis' => '',
            'renavam' => '',
            'device_model' => 'ST8310UM',
            'device_serial' => '',
            'sim_iccid' => '',
            'sim_phone' => '',
            'sim_operator' => 'TIM',
            'avatek_id' => '',
            'status' => 'active',
            'icon' => 'car',
            'odometer' => 0,
            'fuel_capacity' => null
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validações
        if (empty($data['imei']) || strlen($data['imei']) < 15) {
            return new WP_Error('invalid_imei', __('IMEI inválido', 'vehicle-tracker'));
        }
        
        if (empty($data['plate'])) {
            return new WP_Error('invalid_plate', __('Placa é obrigatória', 'vehicle-tracker'));
        }
        
        // Verifica duplicidade
        $exists = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT id FROM {$this->db->vehicles_table} WHERE imei = %s",
            $data['imei']
        ));
        
        if ($exists) {
            return new WP_Error('imei_exists', __('IMEI já cadastrado', 'vehicle-tracker'));
        }
        
        $result = $this->wpdb->insert($this->db->vehicles_table, $data);
        
        if ($result) {
            return $this->wpdb->insert_id;
        }
        
        return new WP_Error('insert_failed', __('Erro ao cadastrar veículo', 'vehicle-tracker'));
    }
    
    /**
     * Atualiza um veículo
     */
    public function update($id, $data) {
        $allowed = array(
            'user_id', 'plate', 'brand', 'model', 'year', 'color',
            'chassis', 'renavam', 'device_model', 'device_serial',
            'sim_iccid', 'sim_phone', 'sim_operator', 'avatek_id',
            'status', 'icon', 'odometer', 'fuel_capacity'
        );
        
        $update_data = array_intersect_key($data, array_flip($allowed));
        
        if (empty($update_data)) {
            return false;
        }
        
        return $this->wpdb->update($this->db->vehicles_table, $update_data, array('id' => $id));
    }
    
    /**
     * Exclui um veículo
     */
    public function delete($id) {
        // Remove posições associadas
        $this->wpdb->delete($this->db->positions_table, array('vehicle_id' => $id));
        
        // Remove alertas associados
        $this->wpdb->delete($this->db->alerts_table, array('vehicle_id' => $id));
        
        // Remove comandos associados
        $this->wpdb->delete($this->db->commands_table, array('vehicle_id' => $id));
        
        // Remove o veículo
        return $this->wpdb->delete($this->db->vehicles_table, array('id' => $id));
    }
    
    /**
     * Obtém última posição de um veículo
     */
    public function get_last_position($vehicle_id) {
        $position = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->db->positions_table} 
             WHERE vehicle_id = %d 
             ORDER BY device_time DESC LIMIT 1",
            $vehicle_id
        ), ARRAY_A);
        
        if ($position) {
            // Busca endereço se não tiver
            if (empty($position['address'])) {
                $position['address'] = $this->reverse_geocode(
                    $position['latitude'],
                    $position['longitude']
                );
            }
        }
        
        return $position;
    }
    
    /**
     * Obtém histórico de posições
     */
    public function get_history($vehicle_id, $start_date, $end_date, $limit = 10000) {
        $positions = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->db->positions_table} 
             WHERE vehicle_id = %d 
             AND device_time BETWEEN %s AND %s 
             ORDER BY device_time ASC 
             LIMIT %d",
            $vehicle_id, $start_date, $end_date, $limit
        ), ARRAY_A);
        
        return $positions;
    }
    
    /**
     * Obtém estatísticas do veículo
     */
    public function get_stats($vehicle_id, $period = 'today') {
        $date_filter = $this->get_date_filter($period);
        
        $stats = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT 
                COUNT(*) as total_positions,
                MAX(speed) as max_speed,
                AVG(speed) as avg_speed,
                SUM(CASE WHEN speed > 0 THEN 1 ELSE 0 END) as moving_points,
                SUM(CASE WHEN ignition = 1 THEN 1 ELSE 0 END) as ignition_on_points,
                MIN(device_time) as first_position,
                MAX(device_time) as last_position
             FROM {$this->db->positions_table} 
             WHERE vehicle_id = %d AND {$date_filter}",
            $vehicle_id
        ), ARRAY_A);
        
        // Calcula distância percorrida
        $stats['distance'] = $this->calculate_distance($vehicle_id, $date_filter);
        
        return $stats;
    }
    
    /**
     * Calcula distância percorrida
     */
    private function calculate_distance($vehicle_id, $date_filter) {
        $positions = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT latitude, longitude FROM {$this->db->positions_table} 
             WHERE vehicle_id = %d AND {$date_filter} 
             ORDER BY device_time ASC",
            $vehicle_id
        ));
        
        $total_distance = 0;
        $prev = null;
        
        foreach ($positions as $pos) {
            if ($prev) {
                $total_distance += $this->haversine_distance(
                    $prev->latitude, $prev->longitude,
                    $pos->latitude, $pos->longitude
                );
            }
            $prev = $pos;
        }
        
        return $total_distance / 1000; // km
    }
    
    /**
     * Verifica se o veículo está online
     */
    private function is_online($last_update) {
        if (!$last_update) {
            return false;
        }
        
        $threshold = get_option('vt_offline_threshold', 300); // 5 minutos
        $last_time = strtotime($last_update);
        
        return (time() - $last_time) < $threshold;
    }
    
    /**
     * Retorna label de status
     */
    private function get_status_label($vehicle) {
        if ($vehicle['status'] === 'blocked') {
            return __('Bloqueado', 'vehicle-tracker');
        }
        if ($vehicle['status'] === 'inactive') {
            return __('Inativo', 'vehicle-tracker');
        }
        if ($vehicle['status'] === 'maintenance') {
            return __('Em manutenção', 'vehicle-tracker');
        }
        if (!$vehicle['is_online']) {
            return __('Offline', 'vehicle-tracker');
        }
        if ($vehicle['is_moving']) {
            return __('Em movimento', 'vehicle-tracker');
        }
        return __('Parado', 'vehicle-tracker');
    }
    
    /**
     * Obtém filtro de data para período
     */
    private function get_date_filter($period) {
        switch ($period) {
            case 'today':
                return "DATE(device_time) = CURDATE()";
            case 'yesterday':
                return "DATE(device_time) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case 'week':
                return "device_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case 'month':
                return "device_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default:
                return "1=1";
        }
    }
    
    /**
     * Calcula distância entre dois pontos
     */
    private function haversine_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000;
        
        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lng = deg2rad($lng2 - $lng1);
        
        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lng / 2) * sin($delta_lng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * Reverse geocoding
     */
    private function reverse_geocode($lat, $lng) {
        $api_key = get_option('vt_google_maps_key', '');
        
        if (empty($api_key)) {
            return null;
        }
        
        $url = sprintf(
            'https://maps.googleapis.com/maps/api/geocode/json?latlng=%s,%s&key=%s&language=pt-BR',
            $lat, $lng, $api_key
        );
        
        $response = wp_remote_get($url, array('timeout' => 10));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['results'][0]['formatted_address'])) {
            return $body['results'][0]['formatted_address'];
        }
        
        return null;
    }
    
    /**
     * Conta veículos por status
     */
    public function count_by_status($user_id = null) {
        $where = $user_id ? $this->wpdb->prepare("WHERE user_id = %d", $user_id) : '';
        
        $counts = $this->wpdb->get_results(
            "SELECT status, COUNT(*) as count FROM {$this->db->vehicles_table} {$where} GROUP BY status",
            ARRAY_A
        );
        
        $result = array(
            'active' => 0,
            'inactive' => 0,
            'blocked' => 0,
            'maintenance' => 0,
            'total' => 0,
            'online' => 0,
            'moving' => 0
        );
        
        foreach ($counts as $count) {
            $result[$count['status']] = intval($count['count']);
            $result['total'] += intval($count['count']);
        }
        
        // Conta online e em movimento
        $threshold = get_option('vt_offline_threshold', 300);
        $online = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->db->vehicles_table} 
             WHERE last_update > DATE_SUB(NOW(), INTERVAL %d SECOND)",
            $threshold
        ));
        
        $moving = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->db->vehicles_table} 
             WHERE last_update > DATE_SUB(NOW(), INTERVAL %d SECOND) AND last_speed > 0",
            $threshold
        ));
        
        $result['online'] = intval($online);
        $result['moving'] = intval($moving);
        
        return $result;
    }
}
