-- Vehicle Tracker Database Installation Script
-- Run this if automatic table creation fails

-- Vehicles table
CREATE TABLE IF NOT EXISTS `{prefix}vt_vehicles` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` bigint(20) UNSIGNED DEFAULT NULL,
    `imei` varchar(20) NOT NULL,
    `sim_number` varchar(20) DEFAULT NULL,
    `plate` varchar(20) NOT NULL,
    `brand` varchar(50) DEFAULT NULL,
    `model` varchar(50) DEFAULT NULL,
    `year` int(4) DEFAULT NULL,
    `color` varchar(30) DEFAULT NULL,
    `chassis` varchar(50) DEFAULT NULL,
    `renavam` varchar(20) DEFAULT NULL,
    `driver_name` varchar(100) DEFAULT NULL,
    `driver_phone` varchar(20) DEFAULT NULL,
    `latitude` decimal(10,8) DEFAULT NULL,
    `longitude` decimal(11,8) DEFAULT NULL,
    `speed` decimal(6,2) DEFAULT 0,
    `direction` int(3) DEFAULT 0,
    `altitude` decimal(8,2) DEFAULT 0,
    `ignition` tinyint(1) DEFAULT 0,
    `blocked` tinyint(1) DEFAULT 0,
    `gps_signal` int(2) DEFAULT 0,
    `gsm_signal` int(3) DEFAULT 0,
    `battery` decimal(5,2) DEFAULT 0,
    `odometer` decimal(12,2) DEFAULT 0,
    `hourmeter` int(11) DEFAULT 0,
    `last_update` datetime DEFAULT NULL,
    `icon` varchar(50) DEFAULT 'car',
    `status` enum('active','inactive','maintenance') DEFAULT 'active',
    `notes` text DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `imei` (`imei`),
    UNIQUE KEY `plate` (`plate`),
    KEY `user_id` (`user_id`),
    KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- History table (partitioned by month for better performance)
CREATE TABLE IF NOT EXISTS `{prefix}vt_history` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `vehicle_id` bigint(20) UNSIGNED NOT NULL,
    `latitude` decimal(10,8) NOT NULL,
    `longitude` decimal(11,8) NOT NULL,
    `speed` decimal(6,2) DEFAULT 0,
    `direction` int(3) DEFAULT 0,
    `altitude` decimal(8,2) DEFAULT 0,
    `ignition` tinyint(1) DEFAULT 0,
    `odometer` decimal(12,2) DEFAULT 0,
    `gps_time` datetime NOT NULL,
    `server_time` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `vehicle_id` (`vehicle_id`),
    KEY `gps_time` (`gps_time`),
    KEY `vehicle_time` (`vehicle_id`, `gps_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Geofences table
CREATE TABLE IF NOT EXISTS `{prefix}vt_geofences` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` bigint(20) UNSIGNED DEFAULT NULL,
    `name` varchar(100) NOT NULL,
    `description` text DEFAULT NULL,
    `type` enum('circle','polygon') NOT NULL DEFAULT 'circle',
    `center_lat` decimal(10,8) DEFAULT NULL,
    `center_lng` decimal(11,8) DEFAULT NULL,
    `radius` int(11) DEFAULT NULL,
    `coordinates` longtext DEFAULT NULL,
    `color` varchar(7) DEFAULT '#3b82f6',
    `alert_on_enter` tinyint(1) DEFAULT 1,
    `alert_on_exit` tinyint(1) DEFAULT 1,
    `active` tinyint(1) DEFAULT 1,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Vehicle-Geofence relationship
CREATE TABLE IF NOT EXISTS `{prefix}vt_vehicle_geofences` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `vehicle_id` bigint(20) UNSIGNED NOT NULL,
    `geofence_id` bigint(20) UNSIGNED NOT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `vehicle_geofence` (`vehicle_id`, `geofence_id`),
    KEY `geofence_id` (`geofence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Geofence events
CREATE TABLE IF NOT EXISTS `{prefix}vt_geofence_events` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `vehicle_id` bigint(20) UNSIGNED NOT NULL,
    `geofence_id` bigint(20) UNSIGNED NOT NULL,
    `event_type` enum('enter','exit') NOT NULL,
    `inside` tinyint(1) DEFAULT 0,
    `latitude` decimal(10,8) NOT NULL,
    `longitude` decimal(11,8) NOT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `vehicle_id` (`vehicle_id`),
    KEY `geofence_id` (`geofence_id`),
    KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Alerts table
CREATE TABLE IF NOT EXISTS `{prefix}vt_alerts` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `vehicle_id` bigint(20) UNSIGNED NOT NULL,
    `alert_type` varchar(50) NOT NULL,
    `message` text NOT NULL,
    `latitude` decimal(10,8) DEFAULT NULL,
    `longitude` decimal(11,8) DEFAULT NULL,
    `priority` enum('low','normal','high','critical') DEFAULT 'normal',
    `status` enum('active','acknowledged','resolved') DEFAULT 'active',
    `acknowledged_by` bigint(20) UNSIGNED DEFAULT NULL,
    `acknowledged_at` datetime DEFAULT NULL,
    `resolved_at` datetime DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `vehicle_id` (`vehicle_id`),
    KEY `alert_type` (`alert_type`),
    KEY `status` (`status`),
    KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Commands table
CREATE TABLE IF NOT EXISTS `{prefix}vt_commands` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `vehicle_id` bigint(20) UNSIGNED NOT NULL,
    `command` varchar(50) NOT NULL,
    `parameters` text DEFAULT NULL,
    `status` enum('pending','sent','delivered','failed') DEFAULT 'pending',
    `response` text DEFAULT NULL,
    `sent_by` bigint(20) UNSIGNED DEFAULT NULL,
    `sent_at` datetime DEFAULT NULL,
    `delivered_at` datetime DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `vehicle_id` (`vehicle_id`),
    KEY `status` (`status`),
    KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Trips table
CREATE TABLE IF NOT EXISTS `{prefix}vt_trips` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `vehicle_id` bigint(20) UNSIGNED NOT NULL,
    `start_time` datetime NOT NULL,
    `end_time` datetime DEFAULT NULL,
    `start_lat` decimal(10,8) NOT NULL,
    `start_lng` decimal(11,8) NOT NULL,
    `end_lat` decimal(10,8) DEFAULT NULL,
    `end_lng` decimal(11,8) DEFAULT NULL,
    `start_address` varchar(255) DEFAULT NULL,
    `end_address` varchar(255) DEFAULT NULL,
    `distance` decimal(10,2) DEFAULT 0,
    `max_speed` decimal(6,2) DEFAULT 0,
    `avg_speed` decimal(6,2) DEFAULT 0,
    `fuel_consumed` decimal(8,2) DEFAULT NULL,
    `status` enum('active','completed') DEFAULT 'active',
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `vehicle_id` (`vehicle_id`),
    KEY `start_time` (`start_time`),
    KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS `idx_history_vehicle_date` ON `{prefix}vt_history` (`vehicle_id`, `gps_time`);
CREATE INDEX IF NOT EXISTS `idx_alerts_vehicle_status` ON `{prefix}vt_alerts` (`vehicle_id`, `status`);
