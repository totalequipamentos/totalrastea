#!/bin/bash

# Vehicle Tracker TCP Server Startup Script

# Configuration
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PHP_BIN="/usr/bin/php"
SERVER_SCRIPT="$SCRIPT_DIR/tcp-server-standalone.php"
PID_FILE="$SCRIPT_DIR/server.pid"
LOG_FILE="$SCRIPT_DIR/server.log"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

start() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo -e "${YELLOW}Server is already running (PID: $PID)${NC}"
            return 1
        fi
    fi

    echo -e "${GREEN}Starting Vehicle Tracker TCP Server...${NC}"
    nohup $PHP_BIN $SERVER_SCRIPT >> $LOG_FILE 2>&1 &
    echo $! > "$PID_FILE"
    sleep 2

    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo -e "${GREEN}Server started successfully (PID: $PID)${NC}"
            return 0
        fi
    fi

    echo -e "${RED}Failed to start server${NC}"
    return 1
}

stop() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo -e "${YELLOW}Stopping server (PID: $PID)...${NC}"
            kill $PID
            rm -f "$PID_FILE"
            echo -e "${GREEN}Server stopped${NC}"
            return 0
        fi
    fi
    echo -e "${YELLOW}Server is not running${NC}"
    return 0
}

restart() {
    stop
    sleep 2
    start
}

status() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo -e "${GREEN}Server is running (PID: $PID)${NC}"
            return 0
        fi
    fi
    echo -e "${RED}Server is not running${NC}"
    return 1
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        restart
        ;;
    status)
        status
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
