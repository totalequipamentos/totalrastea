<?php
/**
 * Vehicle Tracker - Standalone TCP Server
 * 
 * Este script deve ser executado separadamente do WordPress via linha de comando.
 * Uso: php tcp-server-standalone.php
 * 
 * @package VehicleTracker
 */

// Configurações do servidor
define('VT_TCP_HOST', '0.0.0.0');
define('VT_TCP_PORT', 5000);
define('VT_DB_HOST', 'localhost');
define('VT_DB_NAME', 'wordpress');
define('VT_DB_USER', 'root');
define('VT_DB_PASS', '');
define('VT_DB_PREFIX', 'wp_');
define('VT_LOG_FILE', __DIR__ . '/server.log');

/**
 * Logger class
 */
class VT_Logger {
    public static function log($message, $level = 'INFO') {
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        file_put_contents(VT_LOG_FILE, $log_message, FILE_APPEND);
        echo $log_message;
    }
}

/**
 * Database connection
 */
class VT_DB {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        $dsn = "mysql:host=" . VT_DB_HOST . ";dbname=" . VT_DB_NAME . ";charset=utf8mb4";
        $this->pdo = new PDO($dsn, VT_DB_USER, VT_DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function query($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    
    public function insert($table, $data) {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        $this->query($sql, array_values($data));
        return $this->pdo->lastInsertId();
    }
    
    public function update($table, $data, $where, $where_params = []) {
        $set = implode(' = ?, ', array_keys($data)) . ' = ?';
        $sql = "UPDATE {$table} SET {$set} WHERE {$where}";
        $params = array_merge(array_values($data), $where_params);
        return $this->query($sql, $params);
    }
    
    public function fetchOne($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
}

/**
 * Suntech Protocol Parser
 */
class VT_Suntech_Parser {
    
    /**
     * Parse Suntech message
     */
    public static function parse($data) {
        $data = trim($data);
        
        // Identificar tipo de mensagem
        if (strpos($data, 'ST300STT') !== false || strpos($data, 'ST310STT') !== false || 
            strpos($data, 'ST8310STT') !== false) {
            return self::parseStatusReport($data);
        }
        
        if (strpos($data, 'ST300EMG') !== false || strpos($data, 'ST310EMG') !== false ||
            strpos($data, 'ST8310EMG') !== false) {
            return self::parseEmergencyReport($data);
        }
        
        if (strpos($data, 'ST300EVT') !== false || strpos($data, 'ST310EVT') !== false ||
            strpos($data, 'ST8310EVT') !== false) {
            return self::parseEventReport($data);
        }
        
        if (strpos($data, 'ST300ALT') !== false || strpos($data, 'ST310ALT') !== false ||
            strpos($data, 'ST8310ALT') !== false) {
            return self::parseAlertReport($data);
        }
        
        return null;
    }
    
    /**
     * Parse Status Report (STT)
     */
    private static function parseStatusReport($data) {
        // ST8310STT;IMEI;SwVer;Type;MsgID;Date;Time;Cell;Lat;Long;Speed;Course;Sats;Fix;HDOP;Inputs;Outputs;ADC;Odom;HrMeter;Battery
        $parts = explode(';', $data);
        
        if (count($parts) < 17) {
            return null;
        }
        
        return [
            'type' => 'STT',
            'device_id' => $parts[1],
            'sw_version' => $parts[2],
            'report_type' => $parts[3],
            'msg_id' => $parts[4],
            'date' => $parts[5],
            'time' => $parts[6],
            'cell' => $parts[7],
            'latitude' => self::parseCoordinate($parts[8]),
            'longitude' => self::parseCoordinate($parts[9]),
            'speed' => floatval($parts[10]),
            'direction' => floatval($parts[11]),
            'satellites' => intval($parts[12]),
            'gps_fix' => $parts[13] == '1',
            'hdop' => floatval($parts[14]),
            'inputs' => self::parseInputs($parts[15]),
            'outputs' => isset($parts[16]) ? self::parseOutputs($parts[16]) : [],
            'adc' => isset($parts[17]) ? floatval($parts[17]) : 0,
            'odometer' => isset($parts[18]) ? floatval($parts[18]) : 0,
            'hour_meter' => isset($parts[19]) ? intval($parts[19]) : 0,
            'battery' => isset($parts[20]) ? floatval($parts[20]) : 0,
            'timestamp' => self::parseTimestamp($parts[5], $parts[6]),
        ];
    }
    
    /**
     * Parse Emergency Report (EMG)
     */
    private static function parseEmergencyReport($data) {
        $parts = explode(';', $data);
        
        if (count($parts) < 15) {
            return null;
        }
        
        return [
            'type' => 'EMG',
            'device_id' => $parts[1],
            'emergency_type' => $parts[3],
            'date' => $parts[4],
            'time' => $parts[5],
            'latitude' => self::parseCoordinate($parts[7]),
            'longitude' => self::parseCoordinate($parts[8]),
            'speed' => floatval($parts[9]),
            'direction' => floatval($parts[10]),
            'satellites' => intval($parts[11]),
            'gps_fix' => $parts[12] == '1',
            'timestamp' => self::parseTimestamp($parts[4], $parts[5]),
        ];
    }
    
    /**
     * Parse Event Report (EVT)
     */
    private static function parseEventReport($data) {
        $parts = explode(';', $data);
        
        if (count($parts) < 15) {
            return null;
        }
        
        return [
            'type' => 'EVT',
            'device_id' => $parts[1],
            'event_code' => $parts[3],
            'date' => $parts[4],
            'time' => $parts[5],
            'latitude' => self::parseCoordinate($parts[7]),
            'longitude' => self::parseCoordinate($parts[8]),
            'speed' => floatval($parts[9]),
            'direction' => floatval($parts[10]),
            'satellites' => intval($parts[11]),
            'gps_fix' => $parts[12] == '1',
            'timestamp' => self::parseTimestamp($parts[4], $parts[5]),
        ];
    }
    
    /**
     * Parse Alert Report (ALT)
     */
    private static function parseAlertReport($data) {
        $parts = explode(';', $data);
        
        if (count($parts) < 15) {
            return null;
        }
        
        return [
            'type' => 'ALT',
            'device_id' => $parts[1],
            'alert_type' => $parts[3],
            'date' => $parts[4],
            'time' => $parts[5],
            'latitude' => self::parseCoordinate($parts[7]),
            'longitude' => self::parseCoordinate($parts[8]),
            'speed' => floatval($parts[9]),
            'direction' => floatval($parts[10]),
            'satellites' => intval($parts[11]),
            'gps_fix' => $parts[12] == '1',
            'timestamp' => self::parseTimestamp($parts[4], $parts[5]),
        ];
    }
    
    /**
     * Parse coordinate
     */
    private static function parseCoordinate($coord) {
        $value = floatval(str_replace(['+', '-'], '', $coord));
        
        if (strpos($coord, '-') !== false) {
            $value = -$value;
        }
        
        return $value;
    }
    
    /**
     * Parse timestamp
     */
    private static function parseTimestamp($date, $time) {
        // Date format: YYYYMMDD, Time format: HH:MM:SS
        $year = substr($date, 0, 4);
        $month = substr($date, 4, 2);
        $day = substr($date, 6, 2);
        
        return "{$year}-{$month}-{$day} {$time}";
    }
    
    /**
     * Parse input states
     */
    private static function parseInputs($value) {
        $binary = decbin(intval($value));
        return [
            'ignition' => (intval($value) & 1) == 1,
            'input2' => (intval($value) & 2) == 2,
            'input3' => (intval($value) & 4) == 4,
            'input4' => (intval($value) & 8) == 8,
        ];
    }
    
    /**
     * Parse output states
     */
    private static function parseOutputs($value) {
        return [
            'output1' => (intval($value) & 1) == 1,
            'output2' => (intval($value) & 2) == 2,
            'output3' => (intval($value) & 4) == 4,
        ];
    }
    
    /**
     * Build command for Suntech device
     */
    public static function buildCommand($device_id, $command, $params = []) {
        switch ($command) {
            case 'block':
                return "ST300CMD;{$device_id};02;Out1=1";
            case 'unblock':
                return "ST300CMD;{$device_id};02;Out1=0";
            case 'request_position':
                return "ST300CMD;{$device_id};02;STT";
            case 'restart':
                return "ST300CMD;{$device_id};02;Reset";
            default:
                return null;
        }
    }
}

/**
 * Data Handler
 */
class VT_Data_Handler {
    private $db;
    private $prefix;
    
    public function __construct() {
        $this->db = VT_DB::getInstance();
        $this->prefix = VT_DB_PREFIX . 'vt_';
    }
    
    /**
     * Process parsed data
     */
    public function process($parsed_data) {
        if (!$parsed_data || !isset($parsed_data['device_id'])) {
            return false;
        }
        
        // Find vehicle by IMEI
        $vehicle = $this->db->fetchOne(
            "SELECT * FROM {$this->prefix}vehicles WHERE imei = ?",
            [$parsed_data['device_id']]
        );
        
        if (!$vehicle) {
            VT_Logger::log("Unknown device: {$parsed_data['device_id']}", 'WARN');
            return false;
        }
        
        // Update vehicle position
        $this->updateVehiclePosition($vehicle['id'], $parsed_data);
        
        // Save to history
        $this->saveHistory($vehicle['id'], $parsed_data);
        
        // Check geofences
        $this->checkGeofences($vehicle['id'], $parsed_data);
        
        // Check alerts
        $this->checkAlerts($vehicle, $parsed_data);
        
        return true;
    }
    
    /**
     * Update vehicle position
     */
    private function updateVehiclePosition($vehicle_id, $data) {
        $update_data = [
            'latitude' => $data['latitude'],
            'longitude' => $data['longitude'],
            'speed' => $data['speed'],
            'direction' => $data['direction'],
            'ignition' => isset($data['inputs']['ignition']) ? ($data['inputs']['ignition'] ? 1 : 0) : 0,
            'gps_signal' => isset($data['satellites']) ? $data['satellites'] : 0,
            'gsm_signal' => 0,
            'battery' => isset($data['battery']) ? $data['battery'] : 0,
            'odometer' => isset($data['odometer']) ? $data['odometer'] : 0,
            'last_update' => date('Y-m-d H:i:s'),
        ];
        
        $this->db->update(
            $this->prefix . 'vehicles',
            $update_data,
            'id = ?',
            [$vehicle_id]
        );
        
        VT_Logger::log("Updated vehicle {$vehicle_id}: lat={$data['latitude']}, lng={$data['longitude']}, speed={$data['speed']}");
    }
    
    /**
     * Save position to history
     */
    private function saveHistory($vehicle_id, $data) {
        $history_data = [
            'vehicle_id' => $vehicle_id,
            'latitude' => $data['latitude'],
            'longitude' => $data['longitude'],
            'speed' => $data['speed'],
            'direction' => $data['direction'],
            'ignition' => isset($data['inputs']['ignition']) ? ($data['inputs']['ignition'] ? 1 : 0) : 0,
            'odometer' => isset($data['odometer']) ? $data['odometer'] : 0,
            'gps_time' => $data['timestamp'],
            'server_time' => date('Y-m-d H:i:s'),
        ];
        
        $this->db->insert($this->prefix . 'history', $history_data);
    }
    
    /**
     * Check geofences
     */
    private function checkGeofences($vehicle_id, $data) {
        $geofences = $this->db->fetchAll(
            "SELECT g.*, vg.vehicle_id 
             FROM {$this->prefix}geofences g
             JOIN {$this->prefix}vehicle_geofences vg ON g.id = vg.geofence_id
             WHERE vg.vehicle_id = ? AND g.active = 1",
            [$vehicle_id]
        );
        
        foreach ($geofences as $geofence) {
            $inside = $this->isInsideGeofence($data['latitude'], $data['longitude'], $geofence);
            
            // Get last state
            $last_state = $this->db->fetchOne(
                "SELECT inside FROM {$this->prefix}geofence_events 
                 WHERE vehicle_id = ? AND geofence_id = ? 
                 ORDER BY created_at DESC LIMIT 1",
                [$vehicle_id, $geofence['id']]
            );
            
            $was_inside = $last_state ? $last_state['inside'] : null;
            
            // State changed
            if ($was_inside !== null && $was_inside != $inside) {
                $event_type = $inside ? 'enter' : 'exit';
                
                // Save event
                $this->db->insert($this->prefix . 'geofence_events', [
                    'vehicle_id' => $vehicle_id,
                    'geofence_id' => $geofence['id'],
                    'event_type' => $event_type,
                    'inside' => $inside ? 1 : 0,
                    'latitude' => $data['latitude'],
                    'longitude' => $data['longitude'],
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                
                // Create alert
                $this->createAlert($vehicle_id, 'geofence_' . $event_type, 
                    ($inside ? 'Entrou na' : 'Saiu da') . ' geocerca: ' . $geofence['name'],
                    $data['latitude'], $data['longitude']
                );
                
                VT_Logger::log("Geofence {$event_type}: vehicle {$vehicle_id} - {$geofence['name']}");
            }
        }
    }
    
    /**
     * Check if point is inside geofence
     */
    private function isInsideGeofence($lat, $lng, $geofence) {
        if ($geofence['type'] == 'circle') {
            $distance = $this->haversineDistance(
                $lat, $lng,
                $geofence['center_lat'], $geofence['center_lng']
            );
            return $distance <= $geofence['radius'];
        } elseif ($geofence['type'] == 'polygon') {
            $coordinates = json_decode($geofence['coordinates'], true);
            return $this->pointInPolygon($lat, $lng, $coordinates);
        }
        
        return false;
    }
    
    /**
     * Calculate haversine distance
     */
    private function haversineDistance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000; // meters
        
        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lng = deg2rad($lng2 - $lng1);
        
        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lng / 2) * sin($delta_lng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * Check if point is inside polygon
     */
    private function pointInPolygon($lat, $lng, $polygon) {
        $inside = false;
        $count = count($polygon);
        
        for ($i = 0, $j = $count - 1; $i < $count; $j = $i++) {
            if ((($polygon[$i]['lat'] > $lat) != ($polygon[$j]['lat'] > $lat)) &&
                ($lng < ($polygon[$j]['lng'] - $polygon[$i]['lng']) * ($lat - $polygon[$i]['lat']) / ($polygon[$j]['lat'] - $polygon[$i]['lat']) + $polygon[$i]['lng'])) {
                $inside = !$inside;
            }
        }
        
        return $inside;
    }
    
    /**
     * Check alerts
     */
    private function checkAlerts($vehicle, $data) {
        // Speed alert
        if ($data['speed'] > 120) {
            $this->createAlert(
                $vehicle['id'],
                'speed',
                "Velocidade excessiva: {$data['speed']} km/h",
                $data['latitude'],
                $data['longitude']
            );
        }
        
        // Battery alert
        if (isset($data['battery']) && $data['battery'] < 10 && $data['battery'] > 0) {
            $this->createAlert(
                $vehicle['id'],
                'battery',
                "Bateria baixa: {$data['battery']}%",
                $data['latitude'],
                $data['longitude']
            );
        }
        
        // Ignition alerts
        if (isset($data['inputs']['ignition'])) {
            $current_ignition = $data['inputs']['ignition'];
            $last_ignition = $vehicle['ignition'];
            
            if ($current_ignition && !$last_ignition) {
                $this->createAlert(
                    $vehicle['id'],
                    'ignition_on',
                    'Ignição ligada',
                    $data['latitude'],
                    $data['longitude']
                );
            } elseif (!$current_ignition && $last_ignition) {
                $this->createAlert(
                    $vehicle['id'],
                    'ignition_off',
                    'Ignição desligada',
                    $data['latitude'],
                    $data['longitude']
                );
            }
        }
        
        // Emergency alert
        if ($data['type'] == 'EMG') {
            $this->createAlert(
                $vehicle['id'],
                'emergency',
                'Botão de emergência pressionado!',
                $data['latitude'],
                $data['longitude'],
                'critical'
            );
        }
    }
    
    /**
     * Create alert
     */
    private function createAlert($vehicle_id, $type, $message, $lat, $lng, $priority = 'normal') {
        // Check if similar alert exists in last 5 minutes
        $recent = $this->db->fetchOne(
            "SELECT id FROM {$this->prefix}alerts 
             WHERE vehicle_id = ? AND alert_type = ? 
             AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)",
            [$vehicle_id, $type]
        );
        
        if ($recent) {
            return; // Don't create duplicate alerts
        }
        
        $this->db->insert($this->prefix . 'alerts', [
            'vehicle_id' => $vehicle_id,
            'alert_type' => $type,
            'message' => $message,
            'latitude' => $lat,
            'longitude' => $lng,
            'priority' => $priority,
            'status' => 'active',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        
        VT_Logger::log("Alert created: {$type} - {$message}", $priority == 'critical' ? 'CRITICAL' : 'INFO');
    }
}

/**
 * TCP Server
 */
class VT_TCP_Server {
    private $socket;
    private $clients = [];
    private $data_handler;
    
    public function __construct() {
        $this->data_handler = new VT_Data_Handler();
    }
    
    /**
     * Start the server
     */
    public function start() {
        VT_Logger::log("Starting TCP Server on " . VT_TCP_HOST . ":" . VT_TCP_PORT);
        
        // Create socket
        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        
        if ($this->socket === false) {
            VT_Logger::log("Failed to create socket: " . socket_strerror(socket_last_error()), 'ERROR');
            return false;
        }
        
        // Set options
        socket_set_option($this->socket, SOL_SOCKET, SO_REUSEADDR, 1);
        
        // Bind
        if (!socket_bind($this->socket, VT_TCP_HOST, VT_TCP_PORT)) {
            VT_Logger::log("Failed to bind socket: " . socket_strerror(socket_last_error()), 'ERROR');
            return false;
        }
        
        // Listen
        if (!socket_listen($this->socket, 50)) {
            VT_Logger::log("Failed to listen on socket: " . socket_strerror(socket_last_error()), 'ERROR');
            return false;
        }
        
        // Set non-blocking
        socket_set_nonblock($this->socket);
        
        VT_Logger::log("TCP Server started successfully");
        
        // Main loop
        $this->run();
        
        return true;
    }
    
    /**
     * Main server loop
     */
    private function run() {
        while (true) {
            // Check for new connections
            $new_client = @socket_accept($this->socket);
            
            if ($new_client !== false) {
                socket_set_nonblock($new_client);
                $client_id = uniqid('client_');
                $this->clients[$client_id] = [
                    'socket' => $new_client,
                    'connected_at' => time(),
                    'last_activity' => time(),
                    'device_id' => null,
                ];
                
                socket_getpeername($new_client, $addr, $port);
                VT_Logger::log("New connection from {$addr}:{$port} (ID: {$client_id})");
            }
            
            // Process existing clients
            foreach ($this->clients as $client_id => $client) {
                $data = @socket_read($client['socket'], 2048);
                
                if ($data === false) {
                    $error = socket_last_error($client['socket']);
                    if ($error != SOCKET_EWOULDBLOCK && $error != 11) {
                        $this->disconnectClient($client_id);
                    }
                    continue;
                }
                
                if ($data === '') {
                    // Client disconnected
                    $this->disconnectClient($client_id);
                    continue;
                }
                
                // Process received data
                $this->processData($client_id, trim($data));
                $this->clients[$client_id]['last_activity'] = time();
            }
            
            // Check for inactive clients (timeout 300 seconds)
            foreach ($this->clients as $client_id => $client) {
                if (time() - $client['last_activity'] > 300) {
                    VT_Logger::log("Client {$client_id} timed out");
                    $this->disconnectClient($client_id);
                }
            }
            
            // Small delay to prevent CPU hogging
            usleep(10000); // 10ms
        }
    }
    
    /**
     * Process received data
     */
    private function processData($client_id, $data) {
        VT_Logger::log("Received from {$client_id}: {$data}");
        
        // Parse the data
        $parsed = VT_Suntech_Parser::parse($data);
        
        if ($parsed) {
            // Store device ID for this client
            if (isset($parsed['device_id'])) {
                $this->clients[$client_id]['device_id'] = $parsed['device_id'];
            }
            
            // Process the data
            $this->data_handler->process($parsed);
            
            // Send acknowledgment
            $ack = "OK";
            @socket_write($this->clients[$client_id]['socket'], $ack, strlen($ack));
        } else {
            VT_Logger::log("Failed to parse data from {$client_id}", 'WARN');
        }
    }
    
    /**
     * Disconnect client
     */
    private function disconnectClient($client_id) {
        if (isset($this->clients[$client_id])) {
            @socket_close($this->clients[$client_id]['socket']);
            unset($this->clients[$client_id]);
            VT_Logger::log("Client {$client_id} disconnected");
        }
    }
    
    /**
     * Send command to device
     */
    public function sendCommand($device_id, $command) {
        foreach ($this->clients as $client_id => $client) {
            if ($client['device_id'] === $device_id) {
                $cmd = VT_Suntech_Parser::buildCommand($device_id, $command);
                if ($cmd) {
                    @socket_write($client['socket'], $cmd, strlen($cmd));
                    VT_Logger::log("Sent command to {$device_id}: {$cmd}");
                    return true;
                }
            }
        }
        
        VT_Logger::log("Device {$device_id} not connected", 'WARN');
        return false;
    }
    
    /**
     * Stop the server
     */
    public function stop() {
        // Close all client connections
        foreach ($this->clients as $client_id => $client) {
            @socket_close($client['socket']);
        }
        
        // Close main socket
        @socket_close($this->socket);
        
        VT_Logger::log("TCP Server stopped");
    }
}

// Signal handler for graceful shutdown
if (function_exists('pcntl_signal')) {
    declare(ticks = 1);
    
    $server = null;
    
    pcntl_signal(SIGTERM, function() use (&$server) {
        if ($server) $server->stop();
        exit(0);
    });
    
    pcntl_signal(SIGINT, function() use (&$server) {
        if ($server) $server->stop();
        exit(0);
    });
}

// Start the server
try {
    echo "===========================================\n";
    echo "  Vehicle Tracker TCP Server\n";
    echo "  Press Ctrl+C to stop\n";
    echo "===========================================\n\n";
    
    $server = new VT_TCP_Server();
    $server->start();
} catch (Exception $e) {
    VT_Logger::log("Fatal error: " . $e->getMessage(), 'ERROR');
    exit(1);
}
