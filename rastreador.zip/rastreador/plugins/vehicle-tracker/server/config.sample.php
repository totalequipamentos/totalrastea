<?php
/**
 * Sample configuration file for TCP Server
 * 
 * Copy this file to config.php and update the values
 */

// TCP Server Settings
define('VT_TCP_HOST', '0.0.0.0');      // Listen on all interfaces
define('VT_TCP_PORT', 5000);           // Port for device connections

// Database Settings (same as WordPress)
define('VT_DB_HOST', 'localhost');
define('VT_DB_NAME', 'your_wordpress_database');
define('VT_DB_USER', 'your_database_user');
define('VT_DB_PASS', 'your_database_password');
define('VT_DB_PREFIX', 'wp_');         // WordPress table prefix

// Logging
define('VT_LOG_FILE', __DIR__ . '/server.log');
define('VT_LOG_LEVEL', 'INFO');        // DEBUG, INFO, WARN, ERROR

// Timeouts
define('VT_CLIENT_TIMEOUT', 300);      // Client inactivity timeout in seconds
define('VT_SOCKET_TIMEOUT', 30);       // Socket read timeout

// Alerts
define('VT_SPEED_LIMIT', 120);         // km/h - triggers speed alert
define('VT_BATTERY_LOW', 10);          // % - triggers battery alert
