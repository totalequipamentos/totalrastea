<?php
/**
 * Vehicle Tracker Public Functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Public {

    /**
     * Initialize the class
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('vehicle_tracker', array($this, 'tracking_shortcode'));
        add_shortcode('vehicle_tracker_map', array($this, 'map_shortcode'));
        add_shortcode('vehicle_tracker_fleet', array($this, 'fleet_shortcode'));
    }

    /**
     * Enqueue public scripts and styles
     */
    public function enqueue_scripts() {
        // Only load on pages with our shortcodes
        global $post;
        if (!$post || !has_shortcode($post->post_content, 'vehicle_tracker')) {
            return;
        }

        wp_enqueue_style(
            'vehicle-tracker-public',
            VT_PLUGIN_URL . 'assets/css/public-style.css',
            array(),
            VT_VERSION
        );

        wp_enqueue_script(
            'google-maps',
            'https://maps.googleapis.com/maps/api/js?key=' . get_option('vt_google_maps_api_key') . '&libraries=drawing,geometry',
            array(),
            null,
            true
        );

        wp_enqueue_script(
            'vehicle-tracker-public',
            VT_PLUGIN_URL . 'assets/js/public-script.js',
            array('jquery', 'google-maps'),
            VT_VERSION,
            true
        );

        wp_localize_script('vehicle-tracker-public', 'vtPublic', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_public_nonce'),
            'mapCenter' => array(
                'lat' => floatval(get_option('vt_default_latitude', -23.5505)),
                'lng' => floatval(get_option('vt_default_longitude', -46.6333))
            ),
            'mapZoom' => intval(get_option('vt_default_zoom', 12)),
            'updateInterval' => intval(get_option('vt_update_interval', 10)) * 1000,
            'i18n' => array(
                'loading' => __('Carregando...', 'vehicle-tracker'),
                'noVehicles' => __('Nenhum veículo encontrado.', 'vehicle-tracker'),
                'error' => __('Erro ao carregar dados.', 'vehicle-tracker')
            )
        ));
    }

    /**
     * Main tracking shortcode
     * 
     * Usage: [vehicle_tracker user_vehicles="true" show_history="true"]
     */
    public function tracking_shortcode($atts) {
        if (!is_user_logged_in()) {
            return '<p class="vt-login-required">' . __('Faça login para acessar o rastreamento.', 'vehicle-tracker') . '</p>';
        }

        $atts = shortcode_atts(array(
            'user_vehicles' => 'true',
            'show_history' => 'true',
            'show_controls' => 'true',
            'height' => '600px'
        ), $atts);

        $user_id = get_current_user_id();
        $vehicle = new VT_Vehicle();
        $vehicles = $vehicle->get_by_user($user_id);

        ob_start();
        ?>
        <div class="vt-public-wrapper">
            <div class="vt-tracking-container" style="height: <?php echo esc_attr($atts['height']); ?>">
                <?php if ($atts['show_controls'] === 'true'): ?>
                <div class="vt-sidebar">
                    <div class="vt-sidebar-header">
                        <input type="text" class="vt-search" placeholder="<?php esc_attr_e('Buscar veículo...', 'vehicle-tracker'); ?>">
                        <div class="vt-filter-group">
                            <button class="vt-filter active" data-filter="all"><?php _e('Todos', 'vehicle-tracker'); ?></button>
                            <button class="vt-filter" data-filter="online"><?php _e('Online', 'vehicle-tracker'); ?></button>
                            <button class="vt-filter" data-filter="moving"><?php _e('Movimento', 'vehicle-tracker'); ?></button>
                        </div>
                    </div>
                    <div class="vt-vehicle-list">
                        <?php if (empty($vehicles)): ?>
                        <div class="vt-no-vehicles">
                            <span class="dashicons dashicons-car"></span>
                            <p><?php _e('Nenhum veículo cadastrado.', 'vehicle-tracker'); ?></p>
                        </div>
                        <?php else: ?>
                            <?php foreach ($vehicles as $v): ?>
                            <div class="vt-vehicle-card" data-vehicle-id="<?php echo esc_attr($v->id); ?>">
                                <div class="vt-status-dot <?php echo $v->ignition ? 'online' : 'offline'; ?>"></div>
                                <div class="vt-vehicle-info">
                                    <strong><?php echo esc_html($v->plate); ?></strong>
                                    <span><?php echo esc_html($v->model); ?></span>
                                </div>
                                <div class="vt-vehicle-speed">
                                    <?php echo $v->speed ?? 0; ?> km/h
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="vt-map-area">
                    <div id="vt-public-map" class="vt-map"></div>
                    
                    <?php if ($atts['show_history'] === 'true'): ?>
                    <div class="vt-map-toolbar">
                        <button class="vt-toolbar-btn vt-fit-all" title="<?php esc_attr_e('Ver todos', 'vehicle-tracker'); ?>">
                            <span class="dashicons dashicons-fullscreen-alt"></span>
                        </button>
                        <button class="vt-toolbar-btn vt-show-trail" title="<?php esc_attr_e('Mostrar trajeto', 'vehicle-tracker'); ?>">
                            <span class="dashicons dashicons-randomize"></span>
                        </button>
                    </div>
                    <?php endif; ?>
                    
                    <div class="vt-vehicle-panel" style="display: none;">
                        <!-- Filled by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Simple map shortcode
     * 
     * Usage: [vehicle_tracker_map vehicle_id="123" height="400px"]
     */
    public function map_shortcode($atts) {
        $atts = shortcode_atts(array(
            'vehicle_id' => '',
            'height' => '400px',
            'show_info' => 'true'
        ), $atts);

        if (empty($atts['vehicle_id'])) {
            return '<p class="vt-error">' . __('ID do veículo não especificado.', 'vehicle-tracker') . '</p>';
        }

        $vehicle = new VT_Vehicle();
        $v = $vehicle->get_by_id($atts['vehicle_id']);

        if (!$v) {
            return '<p class="vt-error">' . __('Veículo não encontrado.', 'vehicle-tracker') . '</p>';
        }

        // Check user permission
        if (!current_user_can('manage_options') && $v->user_id != get_current_user_id()) {
            return '<p class="vt-error">' . __('Você não tem permissão para visualizar este veículo.', 'vehicle-tracker') . '</p>';
        }

        ob_start();
        ?>
        <div class="vt-single-map-wrapper">
            <div id="vt-single-map-<?php echo esc_attr($atts['vehicle_id']); ?>" 
                 class="vt-single-map" 
                 style="height: <?php echo esc_attr($atts['height']); ?>"
                 data-vehicle-id="<?php echo esc_attr($atts['vehicle_id']); ?>">
            </div>
            
            <?php if ($atts['show_info'] === 'true'): ?>
            <div class="vt-single-info">
                <div class="vt-info-item">
                    <span class="vt-label"><?php _e('Placa:', 'vehicle-tracker'); ?></span>
                    <span class="vt-value"><?php echo esc_html($v->plate); ?></span>
                </div>
                <div class="vt-info-item">
                    <span class="vt-label"><?php _e('Status:', 'vehicle-tracker'); ?></span>
                    <span class="vt-value vt-status-<?php echo $v->ignition ? 'online' : 'offline'; ?>">
                        <?php echo $v->ignition ? __('Online', 'vehicle-tracker') : __('Offline', 'vehicle-tracker'); ?>
                    </span>
                </div>
                <div class="vt-info-item">
                    <span class="vt-label"><?php _e('Velocidade:', 'vehicle-tracker'); ?></span>
                    <span class="vt-value"><?php echo $v->speed ?? 0; ?> km/h</span>
                </div>
                <div class="vt-info-item vt-info-full">
                    <span class="vt-label"><?php _e('Última atualização:', 'vehicle-tracker'); ?></span>
                    <span class="vt-value"><?php echo $v->last_update ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($v->last_update)) : '-'; ?></span>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Fleet overview shortcode
     * 
     * Usage: [vehicle_tracker_fleet columns="4" show_status="true"]
     */
    public function fleet_shortcode($atts) {
        if (!is_user_logged_in()) {
            return '<p class="vt-login-required">' . __('Faça login para visualizar a frota.', 'vehicle-tracker') . '</p>';
        }

        $atts = shortcode_atts(array(
            'columns' => '4',
            'show_status' => 'true',
            'show_location' => 'true'
        ), $atts);

        $user_id = get_current_user_id();
        $vehicle = new VT_Vehicle();
        
        // Admin sees all vehicles, users see only their own
        if (current_user_can('manage_options')) {
            $vehicles = $vehicle->get_all();
        } else {
            $vehicles = $vehicle->get_by_user($user_id);
        }

        if (empty($vehicles)) {
            return '<p class="vt-no-vehicles">' . __('Nenhum veículo encontrado.', 'vehicle-tracker') . '</p>';
        }

        ob_start();
        ?>
        <div class="vt-fleet-grid" style="--columns: <?php echo esc_attr($atts['columns']); ?>">
            <?php foreach ($vehicles as $v): ?>
            <div class="vt-fleet-card">
                <div class="vt-fleet-header">
                    <span class="vt-status-indicator <?php echo $v->ignition ? ($v->speed > 0 ? 'moving' : 'online') : 'offline'; ?>"></span>
                    <h4><?php echo esc_html($v->plate); ?></h4>
                </div>
                
                <div class="vt-fleet-body">
                    <p class="vt-model"><?php echo esc_html($v->brand . ' ' . $v->model); ?></p>
                    
                    <?php if ($atts['show_status'] === 'true'): ?>
                    <div class="vt-fleet-stats">
                        <div class="vt-stat">
                            <span class="vt-stat-value"><?php echo $v->speed ?? 0; ?></span>
                            <span class="vt-stat-label">km/h</span>
                        </div>
                        <div class="vt-stat">
                            <span class="vt-stat-value"><?php echo $v->ignition ? __('Ligada', 'vehicle-tracker') : __('Desligada', 'vehicle-tracker'); ?></span>
                            <span class="vt-stat-label"><?php _e('Ignição', 'vehicle-tracker'); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($atts['show_location'] === 'true' && $v->latitude && $v->longitude): ?>
                    <div class="vt-fleet-location">
                        <span class="dashicons dashicons-location"></span>
                        <span class="vt-address" data-lat="<?php echo esc_attr($v->latitude); ?>" data-lng="<?php echo esc_attr($v->longitude); ?>">
                            <?php _e('Carregando...', 'vehicle-tracker'); ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="vt-fleet-footer">
                    <a href="<?php echo add_query_arg('vehicle', $v->id, get_permalink()); ?>" class="vt-btn-track">
                        <?php _e('Rastrear', 'vehicle-tracker'); ?>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
